#!/usr/bin/env bash
set -euo pipefail

echo "[subtask-gui] Installing/checking dependencies..."

if ! command -v python3 >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y python3 python3-pip
  else
    echo "python3 is missing, and apt-get is unavailable. Please install Python 3 first." >&2
    exit 1
  fi
fi

if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y ffmpeg python3-pyqt5 python3-opencv fonts-noto-cjk
else
  echo "[subtask-gui] apt-get not found; will try Python package install only."
fi

python3 - <<'PY' || python3 -m pip install --user PyQt5 opencv-python imageio-ffmpeg
import cv2
import PyQt5
PY

if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "ffmpeg is still missing. Install it with your system package manager." >&2
  exit 1
fi

python3 - <<'PY'
import cv2
import PyQt5
print("[subtask-gui] Python deps OK")
PY

echo "[subtask-gui] Dependencies OK."
