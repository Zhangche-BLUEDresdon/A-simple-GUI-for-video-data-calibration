#!/usr/bin/env python3
"""Desktop GUI editor for T-layout subtask annotations.

No browser/server needed.

Run:
  python3 /home/admin123/atom/audit_tools/subtask_editor_gui.py

It reads:
  /home/admin123/atom/classified_lerobot_v1/{dataset}/sidecars/submem/v11_final/{episode}/result*.json
  It can also still read the older external sidecar/results roots if selected.

It saves back to the same result.json after creating:
  no extra save backup; reviewer packages should stay clean.
"""

from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import cv2
try:
    import imageio_ffmpeg
except ImportError:
    imageio_ffmpeg = None
from PyQt5.QtCore import Qt, QLibraryInfo, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QImage, QPainter, QPen, QPixmap
from PyQt5.QtWidgets import (
    QApplication,
    QAbstractItemView,
    QComboBox,
    QDoubleSpinBox,
    QGridLayout,
    QHBoxLayout,
    QFrame,
    QLabel,
    QFileDialog,
    QInputDialog,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSlider,
    QSplitter,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QToolBar,
    QVBoxLayout,
    QWidget,
)


ATOM_ROOT = Path(os.environ.get("ATOM_ROOT", Path(__file__).resolve().parents[1])).expanduser().resolve()
CLASSIFIED_ROOT = ATOM_ROOT / "classified_lerobot_v1"
RESULT_ROOT = CLASSIFIED_ROOT
VIDEO_ROOT = ATOM_ROOT / "classified_qwen_subtasks_v1" / "videos_3hz_t"
GUI_VIDEO_ROOT = ATOM_ROOT / "audit_tools" / "gui_videos_3hz_review"
AUDIT_SCRIPT = ATOM_ROOT / "audit_tools" / "classified_qwen_subtasks_v1.py"
FFMPEG_EXE = shutil.which("ffmpeg")
if FFMPEG_EXE is None and imageio_ffmpeg is not None:
    FFMPEG_EXE = imageio_ffmpeg.get_ffmpeg_exe()
FFMPEG_EXE = FFMPEG_EXE or "ffmpeg"

try:
    from replace_char_keys import MAPPING as TEMPLATE_ACTION_MAPPING
except Exception:
    # Fallback keeps the GUI usable if the mapping module is moved away.
    TEMPLATE_ACTION_MAPPING = {}

# Template action keys (缩句) offered in each segment row's dropdown; the
# full English description is expanded later by audit_tools/replace_char_keys.py.
ACTION_KEYS = list(TEMPLATE_ACTION_MAPPING)


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, obj: Any) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def import_audit_module():
    if not AUDIT_SCRIPT.exists():
        return None
    spec = importlib.util.spec_from_file_location("classified_qwen_subtasks_v1", AUDIT_SCRIPT)
    if not spec or not spec.loader:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


AUDIT = import_audit_module()


def snap(x: float) -> float:
    """Snap to 1/3 second, matching 3Hz review granularity."""
    return round(float(x) * 3.0) / 3.0


def safe_segments(segments: list[dict[str, Any]], duration_s: float) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for i, s in enumerate(segments):
        st = max(0.0, min(duration_s, snap(float(s.get("start_s", 0)))))
        en = max(0.0, min(duration_s, snap(float(s.get("end_s", st + 1)))))
        if en <= st:
            en = min(duration_s, snap(st + 1.0))
        label = str(s.get("current_subtask") or f"subtask {i}").strip()
        objs = s.get("manipulated_objects")
        if isinstance(objs, str):
            objs = [x.strip() for x in objs.split(",") if x.strip()]
        elif not isinstance(objs, list):
            objs = []
        ns = dict(s)
        ns["start_s"] = round(st, 3)
        ns["end_s"] = round(en, 3)
        ns["current_subtask"] = label
        ns["manipulated_objects"] = [str(x).strip() for x in objs if str(x).strip()]
        target = ns.get("target_location")
        ns["target_location"] = None if target in (None, "", "None", "null") else str(target)
        ns["confidence"] = ns.get("confidence") or "manual"
        ns["boundary_reason"] = ns.get("boundary_reason") or "manual_edit"
        ns["evidence"] = ns.get("evidence") or "manual GUI edit"
        ns["evidence_time_s"] = float(ns.get("evidence_time_s") or ((st + en) / 2.0))
        out.append(ns)
    out.sort(key=lambda x: (float(x["start_s"]), float(x["end_s"])))
    # Row-boundary editing mode: after sorting, each later subtask starts at
    # the previous subtask's end. This makes the GUI behave like a continuous
    # segmentation editor instead of independent floating spans.
    prev_end = None
    for i, s in enumerate(out):
        if prev_end is not None:
            s["start_s"] = round(prev_end, 3)
            if float(s["end_s"]) <= prev_end:
                s["end_s"] = round(min(duration_s, snap(prev_end + 1 / 3)), 3)
        if float(s["end_s"]) > duration_s:
            s["end_s"] = round(duration_s, 3)
        prev_end = float(s["end_s"])
        s["subtask_id"] = i
    return out


def has_lerobot_dataset_shape(path: Path) -> bool:
    return (path / "source_episode_map.json").exists() or (path / "meta" / "info.json").exists()


def lerobot_dataset_names(root: Path) -> set[str]:
    root = root.expanduser().resolve()
    if has_lerobot_dataset_shape(root):
        return {root.name}
    names: set[str] = set()
    if not root.exists():
        return names
    for child in root.iterdir():
        if not child.is_dir():
            continue
        if has_lerobot_dataset_shape(child):
            names.add(child.name)
        elif has_lerobot_dataset_shape(child / "lerobot"):
            names.add(child.name)
    return names


def result_files_in_episode_dir(ep_dir: Path) -> list[Path]:
    """Return plausible editable result JSON files, in priority order."""
    if not ep_dir.is_dir():
        return []
    files = [
        p for p in ep_dir.glob("result*.json")
        if p.is_file()
        and ".before_gui_edit_" not in p.name
        and ".before_split_clip_fix_" not in p.name
    ]
    preferred = [
        "result.json",
        "result.v11_final_memory.json",
        "result.boundary_refined_memory_v5.json",
    ]
    order = {name: i for i, name in enumerate(preferred)}
    return sorted(files, key=lambda p: (order.get(p.name, 100), -p.stat().st_mtime, p.name))


def find_result_file_in_dataset(result_ds_dir: Path, episode: str) -> Path | None:
    files = result_files_in_episode_dir(result_ds_dir / episode)
    return files[0] if files else None


def discover_result_dataset_dirs(root: Path) -> dict[str, Path]:
    """Discover {dataset: result_dataset_dir} from old results, sidecars, or bundled dirs.

    Supported examples:
      classified_qwen_subtasks_v1/results/{dataset}/episode_*/result.json
      classified_lerobot_v1_sidecars/submem/v11_final/{dataset}/episode_*/result*.json
      classified_lerobot_v1_sidecars/submem/v9_mainlevel/{dataset}/episode_*/result*.json
      {dataset}/sidecars/submem/v11_final/episode_*/result*.json
    """
    root = root.expanduser().resolve()
    candidates: list[Path] = []
    candidate_single_dataset: dict[Path, str] = {}

    def add(p: Path, single_dataset: str | None = None) -> None:
        if p.exists() and p.is_dir() and p not in candidates:
            candidates.append(p)
        if single_dataset is not None:
            candidate_single_dataset[p] = single_dataset

    add(root)
    add(root / "results")
    # Most-current sidecar first. First match wins for duplicate datasets.
    add(root / "submem" / "v11_final")
    add(root / "submem" / "v10_final")
    add(root / "submem" / "v9_mainlevel")
    if (root / "submem").is_dir():
        for p in sorted((root / "submem").iterdir(), reverse=True):
            add(p)
    # Single lerobot dataset layout: dataset_root/sidecars/...
    if has_lerobot_dataset_shape(root):
        add(root / "sidecars", root.name)
        add(root / "sidecars" / "submem" / "v11_final", root.name)
        add(root / "sidecars" / "submem" / "v10_final", root.name)
        add(root / "sidecars" / "submem" / "v9_mainlevel", root.name)
    # Bundled dataset layout: {dataset}/sidecars/...
    for child in sorted([p for p in root.iterdir()] if root.exists() else []):
        if not child.is_dir():
            continue
        if has_lerobot_dataset_shape(child):
            ds_name = child.name
        elif has_lerobot_dataset_shape(child / "lerobot"):
            ds_name = child.name
        else:
            continue
        add(child / "sidecars", ds_name)
        add(child / "sidecars" / "submem" / "v11_final", ds_name)
        add(child / "sidecars" / "submem" / "v10_final", ds_name)
        add(child / "sidecars" / "submem" / "v9_mainlevel", ds_name)
        add(child / "submem" / "v11_final", ds_name)
        add(child / "submem" / "v9_mainlevel", ds_name)

    out: dict[str, Path] = {}
    for base in candidates:
        # Single-dataset result dir: base/episode_*/result*.json
        if any(result_files_in_episode_dir(ep) for ep in base.glob("episode_*")):
            out.setdefault(candidate_single_dataset.get(base, base.name), base)
        # Multi-dataset result dir: base/{dataset}/episode_*/result*.json
        for ds_dir in sorted([p for p in base.iterdir()] if base.exists() else []):
            if not ds_dir.is_dir():
                continue
            if any(result_files_in_episode_dir(ep) for ep in ds_dir.glob("episode_*")):
                out.setdefault(ds_dir.name, ds_dir)
    return out


def extract_subtasks(data: dict[str, Any]) -> tuple[list[dict[str, Any]], str, str]:
    """Return subtasks plus editable storage path and summary."""
    parsed = data.get("parsed") if isinstance(data.get("parsed"), dict) else None
    if parsed is not None and isinstance(parsed.get("subtasks"), list):
        return parsed.get("subtasks") or [], "parsed.subtasks", str(parsed.get("episode_summary") or "")
    if isinstance(data.get("semantic_segments"), list):
        return data.get("semantic_segments") or [], "semantic_segments", str(data.get("episode_summary") or "")
    if isinstance(data.get("subtasks"), list):
        return data.get("subtasks") or [], "subtasks", str(data.get("episode_summary") or "")
    return [], "parsed.subtasks", str(data.get("episode_summary") or "")


def set_subtasks(data: dict[str, Any], path: str, subtasks: list[dict[str, Any]], summary: str) -> None:
    if path == "semantic_segments":
        data["semantic_segments"] = subtasks
        data["episode_summary"] = summary
    elif path == "subtasks":
        data["subtasks"] = subtasks
        data["episode_summary"] = summary
    else:
        parsed = data.get("parsed") if isinstance(data.get("parsed"), dict) else {}
        parsed["subtasks"] = subtasks
        parsed["episode_summary"] = summary
        data["parsed"] = parsed


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    for i in range(1, 10000):
        candidate = path.with_name(f"{path.name}.{i:03d}")
        if not candidate.exists():
            return candidate
    raise RuntimeError(f"Cannot create unique path for {path}")


def move_if_exists(src: Path, dst: Path) -> Path | None:
    if not src.exists():
        return None
    dst = unique_path(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))
    return dst


def wrist_views_need_rotate_180(dataset: str, episode: str) -> bool:
    """Review-video hook kept for compatibility.

    Camera orientation fixes should be applied to the lerobot camera videos
    themselves. Do not rotate again while building review videos.
    """
    return False


class TimelineWidget(QWidget):
    """Single full-episode boundary editor.

    The right-side segment rows are for names and selection. This widget is the
    one place where temporal boundaries are edited:
      b[0]        = first subtask start, so the initial prefix can be trimmed
      b[1..n-1]   = shared boundaries between adjacent subtasks
      b[n]        = last subtask end, so the tail can be trimmed
    """

    selectedChanged = pyqtSignal(int)
    segmentsChanged = pyqtSignal()
    seekRequested = pyqtSignal(float)
    nameEditRequested = pyqtSignal(int)

    def __init__(self):
        super().__init__()
        self.duration = 1.0
        self.position = 0.0
        self.segments: list[dict[str, Any]] = []
        self.selected = -1
        self.drag: tuple[int, float, list[dict[str, Any]]] | None = None
        self.left_pad = 24
        self.right_pad = 24
        self.top_pad = 30
        self.bar_y = 58
        self.bar_h = 30
        self.setMinimumHeight(128)
        self.setMouseTracking(True)

    def set_data(self, duration: float, segments: list[dict[str, Any]], selected: int = 0):
        self.duration = max(0.001, float(duration or 0.001))
        self.segments = segments
        self.selected = selected if segments else -1
        self.update()

    def set_position(self, seconds: float):
        self.position = max(0.0, min(self.duration, seconds))
        self.update()

    def x_for_t(self, t: float) -> int:
        return int(self.left_pad + (self.width() - self.left_pad - self.right_pad) * max(0.0, min(self.duration, t)) / self.duration)

    def t_for_x(self, x: int) -> float:
        return max(0.0, min(self.duration, (x - self.left_pad) / max(1, self.width() - self.left_pad - self.right_pad) * self.duration))

    def boundaries(self) -> list[float]:
        if not self.segments:
            return []
        return [float(self.segments[0]["start_s"])] + [float(s["end_s"]) for s in self.segments]

    def hit_boundary(self, x: int, active_only: bool = False) -> int:
        b = self.boundaries()
        if not b:
            return -1
        active = set(range(len(b)))
        if active_only and 0 <= self.selected < len(self.segments):
            active = {self.selected, self.selected + 1}
        best_k = -1
        best_d = 9999
        for k, t in enumerate(b):
            if k not in active:
                continue
            d = abs(x - self.x_for_t(t))
            if d < best_d:
                best_k = k
                best_d = d
        return best_k if best_d <= 12 else -1

    def hit_segment(self, x: int, y: int) -> int:
        if not (self.bar_y - 10 <= y <= self.bar_y + self.bar_h + 10):
            return -1
        t = self.t_for_x(x)
        for i, s in enumerate(self.segments):
            if float(s["start_s"]) <= t <= float(s["end_s"]):
                return i
        return -1

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#11130f"))
        p.setPen(QPen(QColor("#34382e"), 1))
        p.drawRoundedRect(6, 8, self.width() - 12, self.height() - 16, 12, 12)

        x0 = self.x_for_t(0.0)
        x1 = self.x_for_t(self.duration)
        y = self.bar_y
        p.setPen(QPen(QColor("#34382e"), 1))
        p.setBrush(QColor("#171914"))
        p.drawRoundedRect(x0, y, max(1, x1 - x0), self.bar_h, 8, 8)

        # grid and tick labels
        p.setPen(QColor("#3f4238"))
        for k in range(11):
            x = self.x_for_t(self.duration * k / 10)
            p.drawLine(x, y - 16, x, y + self.bar_h + 16)
        p.setPen(QColor("#aaa48e"))
        for k in range(6):
            t = self.duration * k / 6
            p.drawText(self.x_for_t(t) - 18, 22, f"{t:.1f}")

        palette = ["#7ab7ff", "#7ccf8a", "#e8b84a", "#db7cff", "#ee8b5d"]
        for i, s in enumerate(self.segments):
            sx = self.x_for_t(float(s["start_s"]))
            ex = self.x_for_t(float(s["end_s"]))
            w = max(4, ex - sx)
            if i == self.selected:
                p.setPen(QPen(QColor("#ffffff"), 3))
            else:
                p.setPen(QPen(QColor("#20231d"), 1))
            color = QColor(palette[i % len(palette)])
            p.setBrush(color)
            p.drawRoundedRect(sx, y, w, self.bar_h, 8, 8)
            if i == self.selected:
                p.setPen(QColor("#10110f"))
                p.drawText(sx + 8, y + 20, f"{i:02d} {float(s.get('start_s',0)):.2f}→{float(s.get('end_s',0)):.2f}")

        # Boundary nodes. Yellow = selected subtask editable nodes.
        b = self.boundaries()
        active = set()
        if 0 <= self.selected < len(self.segments):
            active = {self.selected, self.selected + 1}
        for k, t in enumerate(b):
            nx = self.x_for_t(t)
            is_active = k in active
            p.setPen(QPen(QColor("#10110f"), 2))
            p.setBrush(QColor("#ffcf56") if is_active else QColor("#ece7d5"))
            radius = 9 if is_active else 6
            p.drawEllipse(nx - radius, y - 8, radius * 2, self.bar_h + 16)
            p.setPen(QColor("#10110f"))
            p.drawLine(nx, y - 1, nx, y + self.bar_h + 1)

        # Playhead
        px = self.x_for_t(self.position)
        p.setPen(QPen(QColor("#ffcf56"), 2))
        p.drawLine(px, y - 26, px, y + self.bar_h + 28)
        p.setPen(QColor("#ffcf56"))
        p.drawText(px + 5, y + self.bar_h + 26, f"{self.position:.2f}s")

        if 0 <= self.selected < len(self.segments):
            s = self.segments[self.selected]
            p.setPen(QColor("#ece7d5"))
            p.drawText(
                self.left_pad,
                self.height() - 12,
                f"selected {self.selected:02d}: drag yellow start/end nodes; first start node trims prefix",
            )

    def mousePressEvent(self, ev):
        if ev.button() != Qt.LeftButton:
            return
        k = self.hit_boundary(ev.x(), active_only=True)
        if k >= 0:
            self.drag = (k, self.t_for_x(ev.x()), [dict(s) for s in self.segments])
            self.setCursor(Qt.SizeHorCursor)
            self.seekRequested.emit(self.boundaries()[k])
            return
        i = self.hit_segment(ev.x(), ev.y())
        if i >= 0:
            self.selected = i
            self.selectedChanged.emit(i)
        self.seekRequested.emit(self.t_for_x(ev.x()))
        self.update()

    def mouseMoveEvent(self, ev):
        if not self.drag:
            self.setCursor(Qt.SizeHorCursor if self.hit_boundary(ev.x(), active_only=True) >= 0 else Qt.ArrowCursor)
            return
        k, t0, orig = self.drag
        dt = self.t_for_x(ev.x()) - t0
        n = len(self.segments)
        if n == 0:
            return
        min_len = min(1 / 3, self.duration / max(1, n))
        b = [float(orig[0]["start_s"])] + [float(s["end_s"]) for s in orig]
        k = max(0, min(n, k))
        target = snap(b[k] + dt)
        if k == 0:
            target = max(0.0, min(b[1] - min_len, target))
            b[0] = target
        elif k == n:
            target = max(b[n - 1] + min_len, min(self.duration, target))
            b[n] = target
        else:
            # Internal boundary: allow pushing/compressing neighbors, instead
            # of getting stuck immediately against the next segment.
            low = min_len * k
            high = self.duration - min_len * (n - k)
            target = max(low, min(high, target))
            b[k] = target
            for j in range(k - 1, -1, -1):
                if b[j] > b[j + 1] - min_len:
                    b[j] = b[j + 1] - min_len
            for j in range(k + 1, n + 1):
                if b[j] < b[j - 1] + min_len:
                    b[j] = b[j - 1] + min_len
            if b[0] < 0:
                shift = -b[0]
                b = [x + shift for x in b]
            if b[-1] > self.duration:
                shift = b[-1] - self.duration
                b = [x - shift for x in b]
        boundary = b[k]
        for j, s in enumerate(self.segments):
            s["start_s"] = round(snap(b[j]), 3)
            s["end_s"] = round(snap(b[j + 1]), 3)
        self.segmentsChanged.emit()
        self.seekRequested.emit(float(boundary))
        self.update()

    def mouseReleaseEvent(self, _ev):
        self.drag = None
        self.unsetCursor()

    def mouseDoubleClickEvent(self, ev):
        i = self.hit_segment(ev.x(), ev.y())
        if i >= 0:
            self.selected = i
            self.selectedChanged.emit(i)
            self.nameEditRequested.emit(i)


class OldTimelineWidget(QWidget):
    selectedChanged = pyqtSignal(int)
    segmentsChanged = pyqtSignal()
    seekRequested = pyqtSignal(float)
    nameEditRequested = pyqtSignal(int)

    def __init__(self):
        super().__init__()
        self.duration = 1.0
        self.position = 0.0
        self.segments: list[dict[str, Any]] = []
        self.selected = -1
        self.drag: tuple[str, int, float, list[dict[str, Any]]] | None = None
        self.label_w = 300
        self.row_h = 34
        self.top_pad = 34
        self.bottom_pad = 30
        self.setMinimumHeight(220)
        self.setMouseTracking(True)

    def set_data(self, duration: float, segments: list[dict[str, Any]], selected: int = 0):
        self.duration = max(0.001, float(duration or 0.001))
        self.segments = segments
        self.selected = selected if segments else -1
        self.setMinimumHeight(max(220, self.top_pad + self.bottom_pad + len(self.segments) * self.row_h))
        self.update()

    def set_position(self, seconds: float):
        self.position = max(0.0, min(self.duration, seconds))
        self.update()

    def x_for_t(self, t: float) -> int:
        left = self.label_w
        return int(left + (self.width() - left - 16) * max(0.0, min(self.duration, t)) / self.duration)

    def t_for_x(self, x: int) -> float:
        left = self.label_w
        return max(0.0, min(self.duration, (x - left) / max(1, self.width() - left - 16) * self.duration))

    def seg_rect(self, i: int):
        s = self.segments[i]
        x1 = self.x_for_t(float(s["start_s"]))
        x2 = self.x_for_t(float(s["end_s"]))
        y = self.top_pad + i * self.row_h
        return x1, y, max(6, x2 - x1), 24

    def hit_test(self, x: int, y: int):
        for i in range(len(self.segments) - 1, -1, -1):
            rx, ry, rw, rh = self.seg_rect(i)
            if rx <= x <= rx + rw and ry <= y <= ry + rh:
                if x - rx < 8:
                    return "left", i
                if rx + rw - x < 8:
                    return "right", i
                return "move", i
        return None, -1

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#11130f"))
        p.setPen(QPen(QColor("#34382e"), 1))
        p.drawRoundedRect(6, 8, self.width() - 12, self.height() - 16, 12, 12)

        # grid and tick labels. Left column is row labels, right side is time.
        p.setPen(QPen(QColor("#34382e"), 1))
        p.drawLine(self.label_w - 10, 12, self.label_w - 10, self.height() - 18)
        p.setPen(QColor("#3f4238"))
        for k in range(13):
            x = self.x_for_t(self.duration * k / 12)
            p.drawLine(x, 14, x, self.height() - 24)
        p.setPen(QColor("#aaa48e"))
        for k in range(7):
            t = self.duration * k / 6
            p.drawText(self.x_for_t(t) - 18, 26, f"{t:.1f}")

        palette = ["#7ab7ff", "#7ccf8a", "#e8b84a", "#db7cff", "#ee8b5d"]
        for i, s in enumerate(self.segments):
            x, y, w, h = self.seg_rect(i)
            if i == self.selected:
                p.fillRect(10, y - 4, self.width() - 20, h + 8, QColor(232, 184, 74, 32))
            p.setPen(QColor("#aaa48e"))
            row_label = f"{i:02d}  {float(s.get('start_s',0)):.2f}→{float(s.get('end_s',0)):.2f}"
            p.drawText(18, y + 16, row_label)
            p.setPen(QColor("#ece7d5"))
            name = str(s.get("current_subtask", ""))
            p.drawText(128, y + 16, name[:28])
            color = QColor(palette[i % len(palette)])
            if i == self.selected:
                p.setPen(QPen(QColor("#ffffff"), 3))
            else:
                p.setPen(QPen(QColor("#20231d"), 1))
            p.setBrush(color)
            p.drawRoundedRect(x, y, w, h, 6, 6)
            p.setPen(QColor("#08100c"))
            label = f"{float(s.get('end_s',0))-float(s.get('start_s',0)):.2f}s"
            p.drawText(x + 7, y + 16, label)
            p.fillRect(x, y, 6, h, QColor(0, 0, 0, 80))
            p.fillRect(x + w - 6, y, 6, h, QColor(0, 0, 0, 80))

        # playhead
        px = self.x_for_t(self.position)
        p.setPen(QPen(QColor("#ffcf56"), 2))
        p.drawLine(px, 12, px, self.height() - 18)
        p.setPen(QColor("#ffcf56"))
        p.drawText(px + 4, self.height() - 8, f"{self.position:.2f}s")

    def mousePressEvent(self, ev):
        if ev.button() != Qt.LeftButton:
            return
        mode, i = self.hit_test(ev.x(), ev.y())
        if i >= 0:
            self.selected = i
            self.selectedChanged.emit(i)
            self.drag = (mode, i, self.t_for_x(ev.x()), [dict(s) for s in self.segments])
            self.update()
        else:
            self.seekRequested.emit(self.t_for_x(ev.x()))

    def mouseMoveEvent(self, ev):
        if not self.drag:
            mode, _i = self.hit_test(ev.x(), ev.y())
            self.setCursor(Qt.SizeHorCursor if mode in ("left", "right") else Qt.ArrowCursor)
            return
        mode, i, t0, orig_segments = self.drag
        dt = self.t_for_x(ev.x()) - t0
        min_len = 1 / 3
        if mode == "move":
            # In continuous-boundary mode, dragging the middle seeks/selects;
            # boundaries are edited by dragging handles.
            self.seekRequested.emit(self.t_for_x(ev.x()))
            return
        if mode == "left":
            if i == 0:
                new_start = snap(float(orig_segments[0]["start_s"]) + dt)
                new_start = max(0.0, min(float(self.segments[0]["end_s"]) - min_len, new_start))
                self.segments[0]["start_s"] = round(new_start, 3)
            else:
                boundary = snap(float(orig_segments[i]["start_s"]) + dt)
                low = float(self.segments[i - 1]["start_s"]) + min_len
                high = float(self.segments[i]["end_s"]) - min_len
                boundary = max(low, min(high, boundary))
                self.segments[i - 1]["end_s"] = round(boundary, 3)
                self.segments[i]["start_s"] = round(boundary, 3)
        elif mode == "right":
            boundary = snap(float(orig_segments[i]["end_s"]) + dt)
            low = float(self.segments[i]["start_s"]) + min_len
            if i + 1 < len(self.segments):
                high = float(self.segments[i + 1]["end_s"]) - min_len
            else:
                high = self.duration
            boundary = max(low, min(high, boundary))
            self.segments[i]["end_s"] = round(boundary, 3)
            if i + 1 < len(self.segments):
                self.segments[i + 1]["start_s"] = round(boundary, 3)
        self.segmentsChanged.emit()
        self.seekRequested.emit(float(boundary))
        self.update()

    def mouseReleaseEvent(self, _ev):
        self.drag = None

    def mouseDoubleClickEvent(self, ev):
        _mode, i = self.hit_test(ev.x(), ev.y())
        if i >= 0:
            self.selected = i
            self.selectedChanged.emit(i)
            self.nameEditRequested.emit(i)


class TemplateActionCombo(QComboBox):
    """Editable template-action combo.

    Mouse-wheel scrolling picks from the template options, always starting
    from the currently selected template option (or the last picked one when
    the box holds custom text) instead of jumping to an arbitrary entry.
    """

    wheelPicked = pyqtSignal()

    def wheelEvent(self, ev):
        if self.view().isVisible():
            # Popup is open: let the list view handle the wheel itself.
            super().wheelEvent(ev)
            return
        base = self.findText(self.currentText())
        if base < 0:
            base = self.currentIndex()
        if base < 0:
            base = 0
        if self.count() <= 1:
            ev.accept()
            return
        step = -1 if ev.angleDelta().y() > 0 else 1
        self.setCurrentIndex((base + step) % self.count())
        self.wheelPicked.emit()
        ev.accept()


class SegmentBar(QWidget):
    """One row visual preview.

    Boundary editing happens only in the full timeline under the video. Keeping
    row bars non-editable avoids two competing drag surfaces.
    """

    selectedChanged = pyqtSignal(int)
    segmentsChanged = pyqtSignal()
    seekRequested = pyqtSignal(float)

    def __init__(self, index: int, duration: float, segments: list[dict[str, Any]]):
        super().__init__()
        self.index = index
        self.duration = max(0.001, float(duration or 0.001))
        self.segments = segments
        self.setMinimumHeight(28)
        self.setMinimumWidth(180)
        self.setMouseTracking(True)

    def x_for_t(self, t: float) -> int:
        return int(8 + (self.width() - 16) * max(0.0, min(self.duration, t)) / self.duration)

    def t_for_x(self, x: int) -> float:
        return max(0.0, min(self.duration, (x - 8) / max(1, self.width() - 16) * self.duration))

    def bar_rect(self):
        # Old rows are deleted asynchronously (deleteLater); after a segment
        # removal they can still receive a paint event while the shared list
        # is already shorter.  Guard against the stale index.
        if self.index >= len(self.segments):
            return 0, 5, 8, 18
        s = self.segments[self.index]
        x1 = self.x_for_t(float(s["start_s"]))
        x2 = self.x_for_t(float(s["end_s"]))
        return x1, 5, max(8, x2 - x1), 18

    def paintEvent(self, _ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor("#10110f"))
        p.setPen(QPen(QColor("#34382e"), 1))
        p.setBrush(QColor("#171914"))
        p.drawRoundedRect(8, 9, self.width() - 16, 10, 5, 5)
        for k in range(5):
            x = self.x_for_t(self.duration * k / 4)
            p.setPen(QColor("#3f4238"))
            p.drawLine(x, 4, x, 24)
        x, y, w, h = self.bar_rect()
        palette = ["#7ab7ff", "#7ccf8a", "#e8b84a", "#db7cff", "#ee8b5d"]
        p.setPen(QPen(QColor("#f7f1dc"), 1))
        p.setBrush(QColor(palette[self.index % len(palette)]))
        p.drawRoundedRect(x, y, w, h, 6, 6)
        p.setPen(QPen(QColor("#10110f"), 2))
        p.drawLine(x, 6, x, 22)
        p.drawLine(x + w, 6, x + w, 22)

    def mousePressEvent(self, ev):
        if ev.button() != Qt.LeftButton:
            return
        self.selectedChanged.emit(self.index)
        self.seekRequested.emit(self.t_for_x(ev.x()))

    def mouseMoveEvent(self, ev):
        self.setCursor(Qt.ArrowCursor)

    def mouseReleaseEvent(self, _ev):
        self.unsetCursor()


class SegmentRow(QWidget):
    nameChanged = pyqtSignal(int, str)
    insertRequested = pyqtSignal(int)
    deleteRequested = pyqtSignal(int)
    selectedChanged = pyqtSignal(int)
    segmentsChanged = pyqtSignal()
    seekRequested = pyqtSignal(float)

    def __init__(self, index: int, duration: float, segments: list[dict[str, Any]], selected: bool):
        super().__init__()
        self.index = index
        self.segments = segments
        s = segments[index]
        lay = QHBoxLayout(self)
        lay.setContentsMargins(8, 5, 8, 5)
        lay.setSpacing(8)
        self.setObjectName("SegmentRowSelected" if selected else "SegmentRow")
        self.idx = QLabel(f"{index:02d}")
        self.idx.setFixedWidth(28)
        self.time = QLabel(f"{float(s['start_s']):.2f} → {float(s['end_s']):.2f}")
        self.time.setFixedWidth(112)
        self.name = TemplateActionCombo()
        self.name.setEditable(True)
        self.name.setInsertPolicy(QComboBox.NoInsert)
        self.name.addItems(ACTION_KEYS)
        self.name.setCurrentText(str(s.get("current_subtask") or ""))
        self.name.setMinimumWidth(220)
        self.name.setToolTip(
            "下拉选择模板动作（保存后由 replace_char_keys.py 替换为完整英文描述）；"
            "滚轮选择以当前模板选项为起点循环；也可直接输入自定义文本"
        )
        # Picking a template action applies it immediately; typed text is
        # committed when editing finishes (Enter / focus loss).  Wheel picks
        # start from the currently selected template option.
        self.name.activated.connect(
            lambda: self.nameChanged.emit(self.index, self.name.currentText().strip())
        )
        self.name.wheelPicked.connect(
            lambda: self.nameChanged.emit(self.index, self.name.currentText().strip())
        )
        self.name.lineEdit().editingFinished.connect(
            lambda: self.nameChanged.emit(self.index, self.name.currentText().strip())
        )
        self.bar = SegmentBar(index, duration, segments)
        self.bar.selectedChanged.connect(self.selectedChanged)
        self.bar.segmentsChanged.connect(self.segmentsChanged)
        self.bar.seekRequested.connect(self.seekRequested)
        self.insert_btn = QPushButton("+")
        self.insert_btn.setToolTip("split this row / insert new subtask")
        self.insert_btn.setFixedWidth(34)
        self.insert_btn.clicked.connect(lambda: self.insertRequested.emit(self.index))
        self.del_btn = QPushButton("×")
        self.del_btn.setFixedWidth(34)
        self.del_btn.clicked.connect(lambda: self.deleteRequested.emit(self.index))
        lay.addWidget(self.idx)
        lay.addWidget(self.time)
        lay.addWidget(self.name, 3)
        lay.addWidget(self.bar, 2)
        lay.addWidget(self.insert_btn)
        lay.addWidget(self.del_btn)

    def mousePressEvent(self, ev):
        self.selectedChanged.emit(self.index)
        super().mousePressEvent(ev)

    def refresh_from_segment(self, selected: bool):
        s = self.segments[self.index]
        self.time.setText(f"{float(s['start_s']):.2f} → {float(s['end_s']):.2f}")
        if not self.name.hasFocus():
            self.name.setCurrentText(str(s.get("current_subtask") or ""))
        self.setObjectName("SegmentRowSelected" if selected else "SegmentRow")
        self.style().unpolish(self)
        self.style().polish(self)
        self.bar.update()


class VideoCanvas(QLabel):
    """Video display for review mosaics.

    The generated review video is already arranged to fit a desktop window, so
    the canvas preserves the full mosaic instead of cropping away evidence.
    """

    def __init__(self, text: str = ""):
        super().__init__(text)
        self._source_pixmap: QPixmap | None = None
        self.setAlignment(Qt.AlignCenter)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_video_pixmap(self, pixmap: QPixmap) -> None:
        self._source_pixmap = pixmap
        self.update()

    def clear_video_pixmap(self, text: str = "") -> None:
        self._source_pixmap = None
        self.setText(text)
        self.update()

    def paintEvent(self, ev):
        if self._source_pixmap is None or self._source_pixmap.isNull():
            super().paintEvent(ev)
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(self.rect(), QColor("#050505"))
        scaled = self._source_pixmap.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        x = (self.width() - scaled.width()) // 2
        y = (self.height() - scaled.height()) // 2
        p.drawPixmap(x, y, scaled)


class Editor(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Subtask Splicer - local GUI")
        self.resize(1440, 920)
        self.datasets: list[dict[str, Any]] = []
        self.episodes: list[dict[str, Any]] = []
        self.data: dict[str, Any] | None = None
        self.result_path: Path | None = None
        self.result_dataset_dirs: dict[str, Path] = {}
        self.subtask_storage_path = "parsed.subtasks"
        self.lerobot_root = CLASSIFIED_ROOT
        self.result_root = RESULT_ROOT
        self.video_root = VIDEO_ROOT
        self.duration = 0.0
        self.subtasks: list[dict[str, Any]] = []
        self.segment_rows: list[SegmentRow] = []
        self.dirty = False
        self._loading_table = False

        self.cap: cv2.VideoCapture | None = None
        self.video_path: Path | None = None
        self.video_fps = 3.0
        self.video_frames = 0
        self.current_sec = 0.0
        self.playing = False
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.video_tick)

        self.video = VideoCanvas("No video loaded")
        # Keep the minimum modest so the window can be resized freely; the
        # splitter and maximize handle the real available space.
        self.video.setMinimumSize(360, 420)
        self.video.setStyleSheet("background: #050505; color: #aaa48e; border: 1px solid #3b3d32; border-radius: 8px;")

        self.lerobot_root_edit = QLineEdit(str(self.lerobot_root))
        self.browse_lerobot_btn = QPushButton("Browse lerobot")
        self.browse_lerobot_btn.clicked.connect(self.browse_lerobot_root)
        self.load_roots_btn = QPushButton("Load")
        self.load_roots_btn.clicked.connect(self.apply_roots)

        self.dataset_combo = QComboBox()
        self.episode_list = QListWidget()
        self.episode_list.setMinimumWidth(230)
        self.episode_list.currentItemChanged.connect(self.load_selected_episode)
        self.dataset_combo.currentIndexChanged.connect(self.load_episodes)

        self.play_btn = QPushButton("Play/Pause")
        self.play_btn.clicked.connect(self.toggle_play)
        self.prev_btn = QPushButton("Prev")
        self.prev_btn.clicked.connect(lambda: self.step_episode(-1))
        self.next_btn = QPushButton("Next")
        self.next_btn.clicked.connect(lambda: self.step_episode(1))
        self.save_btn = QPushButton("Save JSON")
        self.save_btn.clicked.connect(self.save)
        self.build_video_btn = QPushButton("Build review video")
        self.build_video_btn.clicked.connect(self.build_current_fill_video)
        self.reject_episode_btn = QPushButton("Reject episode")
        self.reject_episode_btn.clicked.connect(self.reject_current_episode)
        self.add_btn = QPushButton("Add segment @ current")
        self.add_btn.clicked.connect(self.add_segment)
        self.del_btn = QPushButton("Delete selected")
        self.del_btn.clicked.connect(self.delete_segment)
        self.sort_btn = QPushButton("Sort by time")
        self.sort_btn.clicked.connect(self.sort_segments)

        self.video_slider = QSlider(Qt.Horizontal)
        self.video_slider.setRange(0, 1000)
        self.video_slider.sliderMoved.connect(self.seek_slider)
        self.time_label = QLabel("0.00 / 0.00")
        self.status_label = QLabel("status")
        self.task_label = QLabel("")
        self.task_label.setWordWrap(True)
        self.flags_label = QLabel("")
        self.flags_label.setWordWrap(True)
        self.summary = QTextEdit()
        self.summary.setMaximumHeight(64)
        self.summary.textChanged.connect(self.mark_dirty)

        self.timeline = TimelineWidget()
        self.timeline.selectedChanged.connect(self.select_segment)
        self.timeline.segmentsChanged.connect(self.timeline_changed)
        self.timeline.seekRequested.connect(self.seek_seconds)
        self.timeline.nameEditRequested.connect(self.edit_segment_name)

        self.rows_container = QWidget()
        self.rows_layout = QVBoxLayout(self.rows_container)
        self.rows_layout.setContentsMargins(4, 4, 4, 4)
        self.rows_layout.setSpacing(6)
        self.rows_scroll = QScrollArea()
        self.rows_scroll.setWidgetResizable(True)
        self.rows_scroll.setWidget(self.rows_container)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["start(auto)", "end/next start", "subtask", "objects", "target"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.itemChanged.connect(self.table_changed)
        self.table.itemSelectionChanged.connect(self.table_selection_changed)
        self.table.setColumnWidth(0, 76)
        self.table.setColumnWidth(1, 76)
        self.table.setColumnWidth(2, 380)
        self.table.setColumnWidth(3, 220)
        self.table.setColumnWidth(4, 190)

        self.build_layout()
        self.load_datasets()
        self.apply_style()

    def build_layout(self):
        tb = QToolBar()
        tb.addWidget(QLabel("Lerobot root "))
        self.lerobot_root_edit.setMinimumWidth(420)
        self.lerobot_root_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        tb.addWidget(self.lerobot_root_edit)
        tb.addWidget(self.browse_lerobot_btn)
        tb.addWidget(self.load_roots_btn)
        tb.addSeparator()
        tb.addWidget(QLabel("Dataset "))
        tb.addWidget(self.dataset_combo)
        tb.addSeparator()
        for w in [self.prev_btn, self.next_btn, self.play_btn, self.build_video_btn, self.reject_episode_btn, self.save_btn]:
            tb.addWidget(w)
        self.addToolBar(tb)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.addWidget(self.video, 4)
        controls = QHBoxLayout()
        controls.addWidget(self.video_slider, 1)
        controls.addWidget(self.time_label)
        lv.addLayout(controls)
        lv.addWidget(QLabel("Full timeline — 选右侧 subtask 后，在这里拖黄色起点/终点；第一个起点可裁掉开头"))
        lv.addWidget(self.timeline)
        lv.addWidget(self.task_label)

        right = QWidget()
        rv = QVBoxLayout(right)
        rv.addWidget(self.episode_list, 1)
        rv.addWidget(self.status_label)
        rv.addWidget(self.flags_label)
        rv.addWidget(QLabel("Episode summary"))
        rv.addWidget(self.summary)
        rv.addWidget(QLabel("Subtasks  —  每行可编辑任务名 / 点击选中 / + 插入 / × 删除；拖边界在左下总时间轴"))
        rv.addWidget(self.rows_scroll, 5)

        split = QSplitter()
        split.addWidget(left)
        split.addWidget(right)
        split.setChildrenCollapsible(False)
        split.setStretchFactor(0, 5)
        split.setStretchFactor(1, 2)
        split.setSizes([1040, 400])
        self.setCentralWidget(split)

    def apply_style(self):
        self.setStyleSheet("""
            QMainWindow, QWidget { background: #10110f; color: #ece7d5; font-family: "Noto Sans CJK SC", "Microsoft YaHei", "DejaVu Sans Mono", monospace; font-size: 12px; }
            QToolBar { background: #181a16; border-bottom: 1px solid #3b3d32; spacing: 8px; padding: 6px; }
            QPushButton { background: #20231d; color: #ece7d5; border: 1px solid #3b3d32; border-radius: 8px; padding: 7px 10px; }
            QPushButton:hover { border-color: #e8b84a; }
            QComboBox, QListWidget, QTableWidget, QTextEdit, QLineEdit { background: #141611; color: #ece7d5; border: 1px solid #3b3d32; border-radius: 8px; }
            QHeaderView::section { background: #20231d; color: #e8b84a; padding: 6px; border: 1px solid #3b3d32; }
            QListWidget::item { padding: 5px; }
            QListWidget::item:selected, QTableWidget::item:selected { background: #614817; color: white; }
            QLabel { color: #aaa48e; }
            QWidget#SegmentRow { background: #141611; border: 1px solid #34382e; border-radius: 10px; }
            QWidget#SegmentRowSelected { background: #231e11; border: 1px solid #e8b84a; border-radius: 10px; }
        """)

    def mark_dirty(self):
        if not self._loading_table:
            self.dirty = True

    def browse_lerobot_root(self):
        p = QFileDialog.getExistingDirectory(self, "Select lerobot dataset root", self.lerobot_root_edit.text())
        if p:
            self.lerobot_root_edit.setText(p)

    def normalize_result_root(self, p: Path) -> Path:
        p = p.expanduser().resolve()
        # Keep sidecar roots intact so discovery can find submem/v11_final etc.
        if (p / "results").is_dir() and not (p / "submem").is_dir():
            return p / "results"
        return p

    def apply_roots(self):
        if not self.confirm_discard():
            return
        lr = Path(self.lerobot_root_edit.text()).expanduser().resolve()
        if not lr.exists():
            QMessageBox.warning(self, "Bad lerobot root", f"不存在：\n{lr}")
            return
        self.lerobot_root = lr
        # One-root mode: result sidecars live inside lerobot datasets.
        self.result_root = lr
        self.video_root = ATOM_ROOT / "classified_qwen_subtasks_v1" / "videos_3hz_t"
        self.dataset_combo.clear()
        self.episode_list.clear()
        self.load_datasets()
        if not self.datasets:
            QMessageBox.warning(
                self,
                "No editable sidecars found",
                "这个 lerobot root 下没有找到可编辑 sidecar：\n"
                f"{lr}\n\n"
                "期望结构例如：\n"
                "{dataset}/sidecars/submem/v11_final/episode_000000/result*.json",
            )
        else:
            self.status_label.setText(f"loaded {len(self.datasets)} dataset(s) from {lr}")

    def dataset_dir(self, dataset: str) -> Path:
        # Accept either a parent containing dataset folders or a single lerobot
        # dataset directory selected directly.
        if has_lerobot_dataset_shape(self.lerobot_root):
            if self.lerobot_root.name == dataset:
                return self.lerobot_root
        # Accept bundled layout: lerobot_root/{dataset}/lerobot/{data,meta,videos}
        bundled = self.lerobot_root / dataset / "lerobot"
        if has_lerobot_dataset_shape(bundled):
            return bundled
        return self.lerobot_root / dataset

    def load_datasets(self):
        self.datasets = []
        self.result_dataset_dirs = discover_result_dataset_dirs(self.result_root)
        known_lerobot = lerobot_dataset_names(self.lerobot_root)
        self.dataset_combo.blockSignals(True)
        self.dataset_combo.clear()
        for ds, p in sorted(self.result_dataset_dirs.items()):
            # Single-dataset JSON root. If lerobot_root itself is a single
            # dataset dir, use that name instead of generic root dir names.
            if p == self.result_root and has_lerobot_dataset_shape(self.lerobot_root):
                ds = self.lerobot_root.name
                self.result_dataset_dirs.setdefault(ds, p)
            if known_lerobot and ds not in known_lerobot:
                continue
            total = self.dataset_total(ds)
            got = sum(1 for ep in p.glob("episode_*") if result_files_in_episode_dir(ep))
            self.datasets.append({"dataset": ds, "total": total, "got": got})
            self.dataset_combo.addItem(f"{ds}  {got}/{total}", ds)
        self.dataset_combo.blockSignals(False)
        if self.datasets:
            self.load_episodes()
        else:
            self.status_label.setText(
                f"no editable sidecars under {self.lerobot_root}; expected {{dataset}}/sidecars/submem/v11_final/episode_*/result*.json"
            )

    def dataset_total(self, dataset: str) -> int:
        ds_dir = self.dataset_dir(dataset)
        p = ds_dir / "source_episode_map.json"
        if p.exists():
            data = load_json(p)
            return len(data if isinstance(data, list) else data.get("episodes", data))
        info = ds_dir / "meta" / "info.json"
        if info.exists():
            try:
                return int(load_json(info).get("total_episodes") or 0)
            except Exception:
                pass
        # Fallback to result count.
        rr = self.result_dataset_dir(dataset)
        return sum(1 for ep in rr.glob("episode_*") if result_files_in_episode_dir(ep))

    def result_file(self, dataset: str, episode: str) -> Path:
        found = find_result_file_in_dataset(self.result_dataset_dir(dataset), episode)
        if found is not None:
            return found
        return self.result_dataset_dir(dataset) / episode / "result.json"

    def result_dataset_dir(self, dataset: str) -> Path:
        if dataset in self.result_dataset_dirs:
            return self.result_dataset_dirs[dataset]
        direct = self.result_root / dataset
        if direct.exists():
            return direct
        if any(result_files_in_episode_dir(ep) for ep in self.result_root.glob("episode_*")):
            return self.result_root
        return direct

    def load_episodes(self):
        ds = self.dataset_combo.currentData()
        if not ds:
            return
        self.episode_list.clear()
        total = self.dataset_total(ds)
        rr = self.result_dataset_dir(ds)
        # Sharded reviewer packages may contain sparse original episode ids,
        # e.g. episode_000012 and episode_000143 only. Always trust actual
        # sidecar episode directories over 0..total-1 enumeration.
        episode_names = sorted(ep.name for ep in rr.glob("episode_*") if result_files_in_episode_dir(ep))
        if not episode_names:
            episode_names = [f"episode_{i:06d}" for i in range(total)]
        for ep in episode_names:
            p = self.result_file(ds, ep)
            if not p.exists():
                continue
            try:
                d = load_json(p)
                flags = d.get("quality_flags") or []
                status = d.get("status") or ("needs_review" if flags else "ok")
                segs, _path, _summary = extract_subtasks(d)
                n = len(segs)
                label = f"{ep}  [{status}]  {n} seg"
            except Exception:
                label = f"{ep}  [bad_json]"
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, ep)
            self.episode_list.addItem(item)
        self.status_label.setText(
            f"{ds}: listed {self.episode_list.count()} episode(s). Select one to load video/segments."
        )

    def confirm_discard(self) -> bool:
        if not self.dirty:
            return True
        ans = QMessageBox.question(self, "Unsaved edits", "当前分段有未保存修改，确定切换吗？")
        return ans == QMessageBox.Yes

    def load_selected_episode(self, cur: QListWidgetItem, _prev: QListWidgetItem | None = None):
        if cur is None:
            return
        if not self.confirm_discard():
            return
        ds = self.dataset_combo.currentData()
        ep = cur.data(Qt.UserRole)
        p = self.result_file(ds, ep)
        self.result_path = p
        d = load_json(p)
        self.data = d
        self.duration = float(d.get("duration_s") or 0.0)
        raw_subtasks, self.subtask_storage_path, episode_summary = extract_subtasks(d)
        if self.duration <= 0 and raw_subtasks:
            self.duration = max(float(s.get("end_s") or 0) for s in raw_subtasks)
        self.subtasks = safe_segments(raw_subtasks, self.duration)
        self._loading_table = True
        self.summary.setPlainText(episode_summary)
        self._loading_table = False
        flags = d.get("quality_flags") or []
        self.status_label.setText(
            f"{ds}/{ep}   duration={self.duration:.2f}s   status={d.get('status') or ('needs_review' if flags else 'ok')}   json={p.name}   path={self.subtask_storage_path}"
        )
        self.flags_label.setText("QA: " + (" · ".join(flags) if flags else "clean"))
        self.task_label.setText("Task: " + str(d.get("task") or d.get("episode_task") or ""))
        video_path = self.find_or_build_video(ds, ep, d)
        if video_path.exists():
            self.open_video(video_path)
        else:
            QMessageBox.warning(self, "Video missing", f"找不到视频：\n{video_path}")
        self.refresh_all(selected=0)
        self.dirty = False

    def refresh_all(self, selected: int | None = None):
        if selected is not None:
            self.timeline.selected = selected
        self.timeline.set_data(self.duration, self.subtasks, self.timeline.selected)
        self.render_segment_rows(self.timeline.selected)
        self.update_time_label()

    def render_segment_rows(self, selected: int = -1):
        while self.rows_layout.count():
            item = self.rows_layout.takeAt(0)
            w = item.widget()
            if w is not None:
                w.deleteLater()
        self.segment_rows = []
        for i, _s in enumerate(self.subtasks):
            row = SegmentRow(i, self.duration, self.subtasks, i == selected)
            row.nameChanged.connect(self.row_name_changed)
            row.insertRequested.connect(self.insert_after_row)
            row.deleteRequested.connect(self.delete_row)
            row.selectedChanged.connect(self.select_segment)
            row.segmentsChanged.connect(self.row_bar_changed)
            row.seekRequested.connect(self.seek_seconds)
            self.rows_layout.addWidget(row)
            self.segment_rows.append(row)
        self.rows_layout.addStretch(1)
        # The rows are added after the window is shown (episode load), and the
        # scroll area keeps the container at the stale viewport size, crushing
        # every row to a few pixels.  Force the container to re-expand.
        self.rows_container.updateGeometry()

    def update_segment_rows_light(self):
        for i, row in enumerate(self.segment_rows):
            if i < len(self.subtasks):
                row.refresh_from_segment(i == self.timeline.selected)
        self.timeline.set_data(self.duration, self.subtasks, self.timeline.selected)

    def update_row_selection_styles(self):
        for i, row in enumerate(self.segment_rows):
            row.refresh_from_segment(i == self.timeline.selected)

    def render_table(self, selected: int = -1):
        self._loading_table = True
        self.table.setRowCount(len(self.subtasks))
        for r, s in enumerate(self.subtasks):
            vals = [
                f"{float(s.get('start_s', 0)):.3f}",
                f"{float(s.get('end_s', 0)):.3f}",
                str(s.get("current_subtask") or ""),
                ", ".join(str(x) for x in (s.get("manipulated_objects") or [])),
                "" if s.get("target_location") is None else str(s.get("target_location")),
            ]
            for c, v in enumerate(vals):
                item = QTableWidgetItem(v)
                if c == 0 and r > 0:
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.table.setItem(r, c, item)
        if 0 <= selected < self.table.rowCount():
            self.table.selectRow(selected)
        self._loading_table = False

    def table_changed(self, item: QTableWidgetItem):
        if self._loading_table:
            return
        r = item.row()
        if not (0 <= r < len(self.subtasks)):
            return
        s = self.subtasks[r]
        try:
            if item.column() == 0:
                if r == 0:
                    s["start_s"] = snap(float(item.text()))
            elif item.column() == 1:
                boundary = snap(float(item.text()))
                boundary = max(float(s["start_s"]) + 1 / 3, min(self.duration, boundary))
                if r + 1 < len(self.subtasks):
                    boundary = min(boundary, float(self.subtasks[r + 1]["end_s"]) - 1 / 3)
                    self.subtasks[r + 1]["start_s"] = boundary
                s["end_s"] = boundary
            elif item.column() == 2:
                s["current_subtask"] = item.text().strip()
            elif item.column() == 3:
                s["manipulated_objects"] = [x.strip() for x in item.text().split(",") if x.strip()]
            elif item.column() == 4:
                s["target_location"] = item.text().strip() or None
            self.subtasks[:] = safe_segments(self.subtasks, self.duration)
            self.dirty = True
            self.timeline.update()
        except Exception as exc:
            QMessageBox.warning(self, "Bad value", str(exc))
            self.render_table(self.timeline.selected)

    def table_selection_changed(self):
        if self._loading_table:
            return
        rows = self.table.selectionModel().selectedRows()
        if rows:
            self.timeline.selected = rows[0].row()
            self.timeline.update()

    def select_segment(self, i: int):
        self.timeline.selected = i
        self.timeline.update()
        self.update_row_selection_styles()

    def row_name_changed(self, i: int, text: str):
        if 0 <= i < len(self.subtasks) and text:
            if self.subtasks[i].get("current_subtask") == text:
                return
            self.subtasks[i]["current_subtask"] = text
            self.dirty = True
            # Light refresh only: rebuilding the rows here would destroy the
            # row widgets while the editable combo's popup is open (focus loss
            # fires editingFinished when the popup opens), closing it instantly.
            self.update_segment_rows_light()

    def insert_after_row(self, i: int):
        if not (0 <= i < len(self.subtasks)):
            return
        s = self.subtasks[i]
        st = float(s["start_s"])
        en = float(s["end_s"])
        if en - st < 2 / 3:
            QMessageBox.warning(self, "Too short", "这个 subtask 太短，无法再切一段。")
            return
        cut = snap((st + en) / 2.0)
        cut = max(st + 1 / 3, min(en - 1 / 3, cut))
        new_seg = dict(s)
        old_end = en
        self.subtasks[i]["end_s"] = round(cut, 3)
        new_seg["start_s"] = round(cut, 3)
        new_seg["end_s"] = round(old_end, 3)
        new_seg["current_subtask"] = "new subtask"
        new_seg["manipulated_objects"] = []
        new_seg["target_location"] = None
        new_seg["confidence"] = "manual"
        new_seg["boundary_reason"] = "manual_insert"
        new_seg["evidence"] = "manual GUI insert"
        new_seg["evidence_time_s"] = cut
        self.subtasks.insert(i + 1, new_seg)
        self.subtasks[:] = safe_segments(self.subtasks, self.duration)
        self.dirty = True
        self.refresh_all(selected=i + 1)

    def delete_row(self, i: int):
        if not (0 <= i < len(self.subtasks)):
            return
        if len(self.subtasks) <= 1:
            QMessageBox.warning(self, "Cannot delete", "至少保留一个 subtask。")
            return
        deleted = self.subtasks[i]
        if i > 0:
            self.subtasks[i - 1]["end_s"] = deleted["end_s"]
        elif i + 1 < len(self.subtasks):
            self.subtasks[i + 1]["start_s"] = deleted["start_s"]
        del self.subtasks[i]
        self.subtasks[:] = safe_segments(self.subtasks, self.duration)
        self.dirty = True
        self.refresh_all(selected=max(0, i - 1))

    def edit_segment_name(self, i: int):
        if not (0 <= i < len(self.subtasks)):
            return
        old = str(self.subtasks[i].get("current_subtask") or "")
        text, ok = QInputDialog.getText(self, "Edit subtask name", f"Subtask {i} name:", text=old)
        if ok and text.strip():
            self.subtasks[i]["current_subtask"] = text.strip()
            self.dirty = True
            self.refresh_all(selected=i)

    def timeline_changed(self):
        self.subtasks[:] = safe_segments(self.subtasks, self.duration)
        self.dirty = True
        self.render_segment_rows(self.timeline.selected)

    def row_bar_changed(self):
        # Do not rebuild row widgets while the mouse is dragging; rebuilding
        # deletes the active SegmentBar and makes the drag appear frozen.
        self.subtasks[:] = safe_segments(self.subtasks, self.duration)
        self.dirty = True
        self.update_segment_rows_light()

    def find_episode_camera_video(self, dataset: str, episode: str, camera_key: str) -> Path | None:
        ds_dir = self.dataset_dir(dataset)
        try:
            idx = int(episode.replace("episode_", ""))
        except Exception:
            idx = 0
        base = ds_dir / "videos" / camera_key
        candidates = [
            base / "chunk-000" / f"file-{idx:03d}.mp4",
            base / "chunk-000" / f"episode_{idx:06d}.mp4",
        ]
        candidates.extend(sorted(base.glob(f"**/file-{idx:03d}.mp4")))
        candidates.extend(sorted(base.glob(f"**/*{idx:06d}*.mp4")))
        for c in candidates:
            if c.exists():
                return c
        return None

    def find_or_build_video(self, dataset: str, episode: str, result: dict[str, Any]) -> Path:
        """Find a review video, building the T-layout cache on demand.

        The reviewer package should be usable immediately after selecting an
        episode. If the cached review mosaic is missing, build it from the
        three lerobot camera videos instead of first showing a missing-file
        error. The explicit "Build review video" button remains useful for
        rebuilding a cache after videos were changed.
        """
        gui_review = GUI_VIDEO_ROOT / dataset / f"{episode}_3hz_review.mp4"
        if gui_review.exists():
            return gui_review

        self.status_label.setText(f"building review video for {dataset}/{episode} ...")
        QApplication.processEvents()
        built = self.build_t_video(dataset, episode, gui_review)
        if built and built.exists():
            self.status_label.setText(f"built review video: {built}")
            return built

        video = result.get("video")
        if video and Path(video).exists():
            return Path(video)
        whole = result.get("whole_video")
        if whole and Path(whole).exists():
            return Path(whole)
        inferred = self.video_root / dataset / f"{episode}_3hz.mp4"
        if inferred.exists():
            return inferred
        return gui_review

    def build_t_video(self, dataset: str, episode: str, out_path: Path) -> Path | None:
        cameras = [
            "observation.images.base_0_rgb",
            "observation.images.left_wrist_0_rgb",
            "observation.images.right_wrist_0_rgb",
        ]
        srcs = [self.find_episode_camera_video(dataset, episode, c) for c in cameras]
        if not all(srcs):
            return None
        out_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = out_path.with_suffix(".tmp.mp4")
        wrist_pre = "hflip,vflip," if wrist_views_need_rotate_180(dataset, episode) else ""
        cmd = [
            FFMPEG_EXE, "-hide_banner", "-loglevel", "error", "-y",
            "-i", str(srcs[0]), "-i", str(srcs[1]), "-i", str(srcs[2]),
            "-filter_complex",
            (
                "[0:v]fps=3,scale=960:720,"
                "drawbox=x=0:y=0:w=iw:h=ih:color=yellow@0.45:t=3,"
                "drawtext=fontcolor=yellow:fontsize=30:box=1:boxcolor=black@0.45:x=12:y=12:text='BASE  %{pts\\:hms}'[b];"
                f"[1:v]fps=3,{wrist_pre}scale=480:360,"
                "drawbox=x=0:y=0:w=iw:h=ih:color=yellow@0.45:t=3,"
                "drawtext=fontcolor=yellow:fontsize=22:box=1:boxcolor=black@0.45:x=10:y=10:text='LEFT WRIST'[l];"
                f"[2:v]fps=3,{wrist_pre}scale=480:360,"
                "drawbox=x=0:y=0:w=iw:h=ih:color=yellow@0.45:t=3,"
                "drawtext=fontcolor=yellow:fontsize=22:box=1:boxcolor=black@0.45:x=10:y=10:text='RIGHT WRIST'[r];"
                "[l][r]vstack=inputs=2[w];"
                "[b][w]hstack=inputs=2[v]"
            ),
            "-map", "[v]", "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(tmp),
        ]
        try:
            subprocess.run(cmd, check=True, timeout=120)
            tmp.replace(out_path)
            return out_path
        except Exception as exc:
            print(f"Failed to build T video for {dataset}/{episode}: {exc}", file=sys.stderr)
            return None

    def build_current_fill_video(self):
        ds = self.dataset_combo.currentData()
        item = self.episode_list.currentItem()
        if not ds or item is None:
            QMessageBox.information(self, "No episode", "先选一个 episode。")
            return
        ep = item.data(Qt.UserRole)
        out = GUI_VIDEO_ROOT / ds / f"{ep}_3hz_review.mp4"
        if out.exists():
            self.open_video(out)
            self.status_label.setText(f"using cached review video: {out}")
            return
        self.status_label.setText(f"building review video for {ds}/{ep} ...")
        QApplication.processEvents()
        built = self.build_t_video(ds, ep, out)
        if built and built.exists():
            self.open_video(built)
            self.status_label.setText(f"built review video: {built}")
        else:
            QMessageBox.warning(self, "Build failed", f"无法生成 review video：\n{out}")

    def reject_current_episode(self):
        ds = self.dataset_combo.currentData()
        item = self.episode_list.currentItem()
        if not ds or item is None:
            QMessageBox.information(self, "No episode", "先选一个 episode。")
            return
        if self.dirty:
            QMessageBox.warning(self, "Unsaved edits", "当前 episode 有未保存编辑；先保存或切换后再 reject。")
            return
        ep = item.data(Qt.UserRole)
        ds_dir = self.dataset_dir(ds)
        result_path = self.result_file(ds, ep)
        result_ep_dir = result_path.parent if result_path.exists() else self.result_dataset_dir(ds) / ep
        try:
            idx = int(str(ep).replace("episode_", ""))
        except Exception:
            idx = -1

        msg = (
            f"确认 reject/delete 当前 episode？\n\n"
            f"{ds}/{ep}\n\n"
            "会移动到 dataset 内 _deleted_episodes/，不是永久 rm：\n"
            "- sidecar 标注目录\n"
            "- 三路相机 episode mp4（如果存在）\n"
            "- GUI review 视频缓存（如果存在）\n\n"
            "注意：data parquet/meta 里这一集的行不会在 GUI 里重写；训练/导出需要按 rejected_episodes.jsonl 排除，"
            "或之后重构一个 clean lerobot。"
        )
        ans = QMessageBox.question(self, "Reject episode", msg)
        if ans != QMessageBox.Yes:
            return

        stamp = time.strftime("%Y%m%d_%H%M%S")
        deleted_root = ds_dir / "_deleted_episodes" / f"{ep}_{stamp}"
        moved: list[dict[str, str]] = []

        # Stop playback before moving files.
        self.playing = False
        self.timer.stop()
        if self.cap is not None:
            self.cap.release()
            self.cap = None

        moved_sidecar = move_if_exists(result_ep_dir, deleted_root / "sidecar" / result_ep_dir.name)
        if moved_sidecar:
            moved.append({"kind": "sidecar", "from": str(result_ep_dir), "to": str(moved_sidecar)})

        cameras = [
            "observation.images.base_0_rgb",
            "observation.images.left_wrist_0_rgb",
            "observation.images.right_wrist_0_rgb",
        ]
        for cam in cameras:
            src = self.find_episode_camera_video(ds, ep, cam)
            if src is None:
                continue
            try:
                rel = src.relative_to(ds_dir)
            except ValueError:
                rel = Path("videos") / cam / f"file-{idx:03d}.mp4"
            dst = deleted_root / "lerobot" / rel
            moved_video = move_if_exists(src, dst)
            if moved_video:
                moved.append({"kind": "video", "from": str(src), "to": str(moved_video)})

        review_paths = [
            GUI_VIDEO_ROOT / ds / f"{ep}_3hz_review.mp4",
            ATOM_ROOT / "audit_tools" / "gui_videos_3hz_t_fill" / ds / f"{ep}_3hz_fill.mp4",
        ]
        for src in review_paths:
            moved_review = move_if_exists(src, deleted_root / "review_cache" / src.name)
            if moved_review:
                moved.append({"kind": "review_cache", "from": str(src), "to": str(moved_review)})

        record = {
            "deleted_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "dataset": ds,
            "episode": ep,
            "episode_index": idx,
            "reason": "manual_reject_from_gui",
            "deleted_root": str(deleted_root),
            "moved": moved,
            "parquet_rows_removed": False,
            "note": "Episode sidecars/videos moved aside. Rebuild a clean lerobot or exclude this manifest before training.",
        }
        manifest = ds_dir / "sidecars" / "rejected_episodes.jsonl"
        manifest.parent.mkdir(parents=True, exist_ok=True)
        with manifest.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

        row = self.episode_list.row(item)
        self.episode_list.takeItem(row)
        self.data = None
        self.result_path = None
        self.subtasks = []
        self.summary.clear()
        self.flags_label.setText("")
        self.task_label.setText("")
        self.video.clear_video_pixmap("Episode rejected/deleted")
        self.refresh_all(selected=-1)
        self.dirty = False
        self.status_label.setText(f"rejected {ds}/{ep}; moved {len(moved)} item(s) to {deleted_root}")
        QMessageBox.information(
            self,
            "Rejected",
            f"已 reject：{ds}/{ep}\n\n移动 {len(moved)} 个项目到：\n{deleted_root}\n\n记录：\n{manifest}",
        )

    def open_video(self, path: Path):
        if self.cap is not None:
            self.cap.release()
        self.video_path = path
        self.cap = cv2.VideoCapture(str(path))
        if not self.cap.isOpened():
            self.video.clear_video_pixmap(f"Cannot open video:\n{path}")
            return
        fps = float(self.cap.get(cv2.CAP_PROP_FPS) or 0)
        self.video_fps = fps if fps > 0.1 else 3.0
        self.video_frames = int(self.cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        self.current_sec = 0.0
        self.show_frame_at(0.0)

    def show_frame_at(self, sec: float):
        if self.cap is None or not self.cap.isOpened():
            return
        self.current_sec = max(0.0, min(self.duration, float(sec)))
        frame_idx = int(round(self.current_sec * self.video_fps))
        if self.video_frames > 0:
            frame_idx = max(0, min(self.video_frames - 1, frame_idx))
        self.cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ok, frame = self.cap.read()
        if not ok or frame is None:
            return
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = frame.shape
        img = QImage(frame.data, w, h, ch * w, QImage.Format_RGB888).copy()
        self.video.set_video_pixmap(QPixmap.fromImage(img))
        self.timeline.set_position(self.current_sec)
        if not self.video_slider.isSliderDown():
            self.video_slider.setValue(int(max(0.0, min(1.0, self.current_sec / max(0.001, self.duration))) * 1000))
        self.update_time_label()

    def video_tick(self):
        if not self.playing:
            return
        nxt = self.current_sec + max(1.0 / max(0.1, self.video_fps), 1.0 / 30.0)
        if nxt >= self.duration:
            self.playing = False
            self.timer.stop()
            nxt = self.duration
        self.show_frame_at(nxt)

    def resizeEvent(self, ev):
        super().resizeEvent(ev)
        if self.cap is not None and self.cap.isOpened():
            self.show_frame_at(self.current_sec)

    def update_time_label(self):
        self.time_label.setText(f"{self.current_sec:.2f} / {self.duration:.2f}s")

    def seek_slider(self, value: int):
        self.seek_seconds(value / 1000.0 * self.duration)

    def seek_seconds(self, sec: float):
        self.show_frame_at(sec)

    def toggle_play(self):
        if self.playing:
            self.playing = False
            self.timer.stop()
        else:
            self.playing = True
            self.timer.start(max(30, int(1000 / max(0.1, self.video_fps))))

    def step_episode(self, delta: int):
        row = self.episode_list.currentRow()
        new = max(0, min(self.episode_list.count() - 1, row + delta))
        self.episode_list.setCurrentRow(new)

    def add_segment(self):
        t = snap(self.current_sec)
        new_seg = {
            "start_s": t,
            "end_s": min(self.duration, snap(t + 2.0)),
            "current_subtask": "new subtask",
            "manipulated_objects": [],
            "target_location": None,
            "confidence": "manual",
            "boundary_reason": "manual_edit",
            "evidence": "manual GUI edit",
            "evidence_time_s": t,
        }
        insert_at = len(self.subtasks)
        for i, s in enumerate(self.subtasks):
            st = float(s["start_s"])
            en = float(s["end_s"])
            if st + 1 / 3 <= t <= en - 1 / 3:
                old_end = en
                s["end_s"] = t
                new_seg["start_s"] = t
                new_seg["end_s"] = old_end
                insert_at = i + 1
                break
            if t < st:
                new_seg["start_s"] = st
                new_seg["end_s"] = min(self.duration, snap(st + 1.0))
                insert_at = i
                break
        self.subtasks.insert(insert_at, new_seg)
        self.subtasks[:] = safe_segments(self.subtasks, self.duration)
        self.dirty = True
        self.refresh_all(selected=insert_at)

    def delete_segment(self):
        self.delete_row(self.timeline.selected)

    def sort_segments(self):
        self.subtasks[:] = safe_segments(self.subtasks, self.duration)
        self.dirty = True
        self.refresh_all(selected=0)

    def save(self):
        if not self.data or not self.result_path:
            return
        try:
            self.subtasks[:] = safe_segments(self.subtasks, self.duration)
            summary = self.summary.toPlainText().strip()
            set_subtasks(self.data, self.subtask_storage_path, self.subtasks, summary)
            if self.subtask_storage_path == "parsed.subtasks" and AUDIT is not None:
                parsed = self.data.get("parsed") if isinstance(self.data.get("parsed"), dict) else {}
                parsed = AUDIT.normalize_parsed(parsed)
                dataset = self.data.get("dataset") or (self.dataset_combo.currentData() or "")
                flags = AUDIT.quality_flags(parsed, self.duration, AUDIT.long_segment_threshold_s(dataset), dataset=dataset)
                self.data["quality_flags"] = flags
                self.data["status"] = "ok" if not flags else "needs_review"
                self.data["parsed"] = parsed
                saved_count = len(parsed.get("subtasks") or [])
            else:
                # Sidecar/final-memory files already have their own validation
                # fields. Mark the manual edit without forcing the older Qwen
                # QA schema onto them.
                self.data["status"] = self.data.get("status") or "manual_edited"
                saved_count = len(self.subtasks)
            self.data["manual_subtask_edit"] = {
                "edited_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "editor": "subtask_editor_gui.py",
                "storage_path": self.subtask_storage_path,
                "subtask_count": saved_count,
                "backup_created": False,
            }
            write_json(self.result_path, self.data)
            self.dirty = False
            QMessageBox.information(self, "Saved", f"已保存：\n{self.result_path}")
            self.load_selected_episode(self.episode_list.currentItem())
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", str(exc))

    def closeEvent(self, ev):
        if self.confirm_discard():
            self.playing = False
            self.timer.stop()
            if self.cap is not None:
                self.cap.release()
            ev.accept()
        else:
            ev.ignore()


def main():
    # Importing OpenCV may point Qt at OpenCV's incomplete plugin directory.
    # Always use the platform plugins shipped with this PyQt5 installation.
    os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(
        Path(QLibraryInfo.location(QLibraryInfo.PluginsPath)) / "platforms"
    )
    app = QApplication(sys.argv)
    w = Editor()
    screen = app.primaryScreen().availableGeometry()
    width = max(640, min(1200, screen.width() - 40))
    height = max(480, min(800, screen.height() - 40))
    w.setGeometry(screen.left() + 20, screen.top() + 20, width, height)
    w.show()
    QTimer.singleShot(300, lambda: (
        w.showNormal(),
        w.setGeometry(screen.left() + 20, screen.top() + 20, width, height),
        w.raise_(),
        w.activateWindow(),
    ))
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
