#!/usr/bin/env bash
# 启动预填标注 GUI（独立版）。
#
# 数据根目录通过环境变量 ATOM_ROOT 指定（默认取本脚本的上一级目录）：
#   - classified_lerobot_v1/                    数据集与 episode JSON（sidecars/submem/v11_final/...）
#   - audit_tools/gui_videos_3hz_review/        预构建 3 摄像头合成视频
#   - audit_tools/classified_qwen_subtasks_v1.py AUDIT 模块（可选，缺失时 AUDIT=None）
#
# 用法：
#   ./run_guiproject.sh                          # 默认 ATOM_ROOT = 本仓库的上一级目录
#   ATOM_ROOT=/path/to/data ./run_guiproject.sh  # 显式指定数据根
#
# GUI 只写回 episode JSON（与原版一致）；不创建/移动数据根下任何文件。
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export ATOM_ROOT="${ATOM_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
if [ ! -d "${ATOM_ROOT}/classified_lerobot_v1" ]; then
    echo "警告：${ATOM_ROOT} 下没有 classified_lerobot_v1，数据根可能不正确。"
    echo "      请用 ATOM_ROOT=/path/to/data ./run_guiproject.sh 显式指定。"
fi
echo "ATOM_ROOT=${ATOM_ROOT}"
exec python3 "${SCRIPT_DIR}/subtask_editor_gui_prefill.py"
