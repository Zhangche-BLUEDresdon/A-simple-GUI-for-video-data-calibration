#!/usr/bin/env python3
"""Replace short action keys (缩句) in episode JSONs with full EN descriptions.

The GUI (subtask_editor_gui_prefill.py) saves subtasks whose names are short
keys like "上下擦".  After a reviewer finishes stamping an episode, run this
script to expand the keys into the canonical English descriptions.

Usage:
    python3 replace_char_keys.py --all            # scan & replace every episode
    python3 replace_char_keys.py 000005 000042    # replace specific episodes
    python3 replace_char_keys.py --no-write --all # preview only, change nothing

Replacement is exact full-string match on current_subtask (after stripping).
A .bak copy of a file is created the first time it is modified.  Idempotent:
files already expanded are left untouched, so re-running is safe.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

# 缩句 key -> canonical English subtask description
MAPPING: dict[str, str] = {
    "拿板擦": "Move to the blackboard eraser, tip it bottom-side up, and grasp it",
    "移板擦": "Move the blackboard eraser in front of the vase",
    "抓瓶沿": "Grasp the upper rim of the vase and hold it in place",
    "上下擦": (
        "Wipe the writing in front of the vase with the blackboard eraser "
        "using an up-and-down motion"
    ),
    "转压瓶": "Rotate the vase counterclockwise, then press it down onto the table",
    "收板擦": "Retract and release the blackboard eraser",
    "移瓶收臂": "Move the vase farther away and retract the arm",
}

DATASET_DIR = (
    Path(__file__).resolve().parents[1]
    / "classified_lerobot_v1"
    / "lerobot_v3_4to1_vase_force"
)
RESULT_DIR = Path(
    os.environ.get(
        "REPLACE_CHAR_KEYS_RESULT_DIR",
        str(DATASET_DIR / "sidecars" / "submem" / "v11_final"),
    )
)

# Storage locations where subtask lists can live (the GUI writes parsed.subtasks)
STORAGE_PATHS = ("parsed.subtasks", "semantic_segments", "subtasks")


def iter_subtask_lists(data: dict) -> list[list[dict]]:
    out: list[list[dict]] = []
    parsed = data.get("parsed")
    if isinstance(parsed, dict) and isinstance(parsed.get("subtasks"), list):
        out.append(parsed["subtasks"])
    if isinstance(data.get("semantic_segments"), list):
        out.append(data["semantic_segments"])
    if isinstance(data.get("subtasks"), list):
        out.append(data["subtasks"])
    return out


def looks_like_unmapped_key(label: str) -> bool:
    """Heuristic for short shorthand labels we don't know yet."""
    if not label:
        return False
    return len(label) <= 8 and " " not in label and any(
        ch not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_."
        for ch in label
    ) or label.startswith("new subtask")


def process_file(path: Path, no_write: bool) -> tuple[str, int, list[str]]:
    """Return (episode_id, replaced_count, warnings)."""
    data = json.loads(path.read_text(encoding="utf-8"))
    replaced = 0
    warnings: list[str] = []
    for subtasks in iter_subtask_lists(data):
        for seg in subtasks:
            raw = str(seg.get("current_subtask") or "").strip()
            if not raw:
                continue
            if raw in MAPPING:
                seg["current_subtask"] = MAPPING[raw]
                replaced += 1
            elif looks_like_unmapped_key(raw):
                warnings.append(f"unknown key: {raw!r}")
    if replaced == 0:
        return str(data.get("episode_id") or path.parent.name), 0, warnings
    if not no_write:
        backup = path.with_name(path.name + ".bak")
        if not backup.exists():
            backup.write_bytes(path.read_bytes())
        path.write_text(
            json.dumps(data, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    return str(data.get("episode_id") or path.parent.name), replaced, warnings


def main() -> int:
    args = sys.argv[1:]
    no_write = "--no-write" in args
    args = [a for a in args if a != "--no-write"]
    all_flag = "--all" in args
    args = [a for a in args if a != "--all"]

    if all_flag and args:
        print("error: --all 不能与 episode 号同时使用", file=sys.stderr)
        return 2
    if not all_flag and not args:
        print(__doc__)
        return 2

    if all_flag:
        targets = sorted(RESULT_DIR.glob("episode_*/result*.json"))
    else:
        targets = []
        for ep in args:
            padded = ep if ep.startswith("episode_") else f"episode_{ep:>06}" if ep.isdigit() else ep
            hits = sorted(RESULT_DIR.glob(f"{padded}/result*.json"))
            if not hits:
                print(f"warning: 找不到 {padded} 的 JSON", file=sys.stderr)
            targets.extend(hits)

    total_replaced = 0
    for path in targets:
        episode, replaced, warnings = process_file(path, no_write)
        if replaced:
            action = "预览替换" if no_write else "已替换"
            print(f"{action} {episode}: {replaced} 个键")
        for w in warnings:
            print(f"  ⚠ {episode}: {w}")
        total_replaced += replaced
    print(f"共处理 {len(targets)} 个文件，替换 {total_replaced} 个键"
          + ("（预览模式，未写入）" if no_write else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
