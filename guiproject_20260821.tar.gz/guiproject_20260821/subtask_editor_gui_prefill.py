#!/usr/bin/env python3
"""Independent prefill edition of the subtask annotation GUI.

The original ``subtask_editor_gui.py`` remains the base editor.  This module
subclasses it and adds a reusable template plus sequential boundary stamping.
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from PyQt5.QtCore import QLibraryInfo, Qt
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDockWidget,
    QGroupBox,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QInputDialog,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QShortcut,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from subtask_editor_gui import (
    ACTION_KEYS,
    AUDIT,
    Editor,
    load_json,
    safe_segments,
    set_subtasks,
    snap,
    write_json,
)
from functools import partial


CUSTOM_TEMPLATE_PATH = Path(__file__).with_name("prefill_custom_template.json")
# Alt+数字 快速标记映射（数字字符串 → 模板状态缩句 key），GUI 全局配置。
ALT_MAP_PATH = Path(__file__).with_name("prefill_alt_map.json")
# 与原版 audit_tools 不同，副本不再依赖 parents[1] 推断数据根；
# 数据根由 ATOM_ROOT 环境变量显式指定（见 run_guiproject.sh），
# 与原版行为一致：加载 episode_000001 作为比例时间戳参考。
REFERENCE_EPISODE_DIR = (
    Path(os.environ.get("ATOM_ROOT", Path(__file__).resolve().parents[1]))
    .expanduser()
    .resolve()
    / "classified_lerobot_v1"
    / "dataset_80_random_labeled"
    / "sidecars"
    / "submem"
    / "v11_final"
    / "episode_000001"
)


def load_saved_templates() -> dict[str, dict[str, Any]]:
    """Load the named, full-snapshot template library."""
    if not CUSTOM_TEMPLATE_PATH.exists():
        return {}
    try:
        data = json.loads(CUSTOM_TEMPLATE_PATH.read_text(encoding="utf-8"))
        templates = data.get("templates")
        if not isinstance(templates, dict):
            return {}
        return {
            str(name): value
            for name, value in templates.items()
            if isinstance(value, dict)
            and value.get("segments")
            and float(value.get("source_duration") or 0.0) > 0
        }
    except Exception:
        return {}


def write_saved_templates(templates: dict[str, dict[str, Any]]) -> None:
    CUSTOM_TEMPLATE_PATH.write_text(
        json.dumps(
            {"version": 3, "templates": templates},
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )


BUILTIN_TEMPLATES: dict[str, dict[str, Any]] = {
    "抽屉转移插头 + 两只鸭子入杯": {
        "summary": (
            "Open both drawers, transfer the plug from the left drawer to the "
            "right drawer, and close both drawers."
        ),
        "lines": [
            "move to left drawer handle and grasp it | left drawer handle |",
            "pull open left drawer and release handle | left drawer | open position",
            "move to right drawer handle and grasp it | right drawer handle |",
            "pull open right drawer and release handle | right drawer | open position",
            "move to plug in left drawer and grasp it | plug |",
            "move plug to right drawer and release it | plug, left drawer, right drawer | inside right drawer",
            "close gripper and move to front of right drawer | right drawer |",
            "push right drawer closed | right drawer | closed position",
            "move to left drawer and push it closed | left drawer | closed position",
            "open gripper and return to home position | | home position",
            "move to blue duck and grasp it | blue duck |",
            "move blue duck into cup and release it | blue duck, cup | inside cup",
            "move to orange duck and grasp it | orange duck |",
            "move orange duck into cup and release it | orange duck, cup | inside cup",
            "return to home position | | home position",
        ],
    },
    "只做抽屉与插头": {
        "summary": (
            "Open both drawers, transfer the plug from the left drawer to the "
            "right drawer, and close both drawers."
        ),
        "lines": [
            "move to left drawer handle and grasp it | left drawer handle |",
            "pull open left drawer and release handle | left drawer | open position",
            "move to right drawer handle and grasp it | right drawer handle |",
            "pull open right drawer and release handle | right drawer | open position",
            "move to plug in left drawer and grasp it | plug |",
            "move plug to right drawer and release it | plug, left drawer, right drawer | inside right drawer",
            "close gripper and move to front of right drawer | right drawer |",
            "push right drawer closed | right drawer | closed position",
            "move to left drawer and push it closed | left drawer | closed position",
            "open gripper and return to home position | | home position",
        ],
    },
    "只放两只鸭子": {
        "summary": "Place the blue duck and the orange duck into the cup.",
        "lines": [
            "move to blue duck and grasp it | blue duck |",
            "move blue duck into cup and release it | blue duck, cup | inside cup",
            "move to orange duck and grasp it | orange duck |",
            "move orange duck into cup and release it | orange duck, cup | inside cup",
        ],
    },
}


def parse_template(text: str) -> list[dict[str, Any]]:
    """Parse ``subtask | comma-separated objects | target`` template lines."""
    parsed: list[dict[str, Any]] = []
    for line_no, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [part.strip() for part in line.split("|", 2)]
        name = parts[0]
        if not name:
            raise ValueError(f"第 {line_no} 行缺少 subtask 名称")
        objects = []
        if len(parts) >= 2 and parts[1]:
            objects = [item.strip() for item in parts[1].split(",") if item.strip()]
        target = parts[2] if len(parts) >= 3 and parts[2] else None
        parsed.append(
            {
                "current_subtask": name,
                "manipulated_objects": objects,
                "target_location": target,
            }
        )
    if not parsed:
        raise ValueError("模板中没有可用的 subtask")
    return parsed


def evenly_spaced_segments(
    template_rows: list[dict[str, Any]], duration: float
) -> list[dict[str, Any]]:
    count = len(template_rows)
    if duration < count / 3.0:
        raise ValueError(f"视频只有 {duration:.2f}s，无法容纳 {count} 个最短 1/3 秒分段")
    boundaries = [snap(duration * i / count) for i in range(count + 1)]
    boundaries[0] = 0.0
    boundaries[-1] = duration
    result: list[dict[str, Any]] = []
    for index, row in enumerate(template_rows):
        start = boundaries[index]
        end = boundaries[index + 1]
        result.append(
            {
                **row,
                "start_s": start,
                "end_s": end,
                "confidence": "manual",
                "boundary_reason": "prefill_even_split",
                "evidence": "prefill template; reviewer adjusts boundaries",
                "evidence_time_s": round((start + end) / 2.0, 3),
                "subtask_id": index,
            }
        )
    return safe_segments(result, duration)


def scale_segments_by_ratios(
    source_segments: list[dict[str, Any]],
    source_duration: float,
    target_duration: float,
) -> list[dict[str, Any]]:
    """Copy labels and scale timestamps proportionally to a new duration."""
    if source_duration <= 0 or target_duration <= 0:
        raise ValueError("源视频和目标视频时长必须大于 0")
    scaled: list[dict[str, Any]] = []
    for index, source in enumerate(source_segments):
        start_ratio = float(source["start_s"]) / source_duration
        end_ratio = float(source["end_s"]) / source_duration
        row = dict(source)
        row["start_s"] = snap(start_ratio * target_duration)
        row["end_s"] = (
            target_duration
            if index == len(source_segments) - 1
            else snap(end_ratio * target_duration)
        )
        row["boundary_reason"] = "copied_proportional_timestamps"
        row["evidence"] = "copied from previous episode by proportional timestamp"
        row["evidence_time_s"] = round(
            (float(row["start_s"]) + float(row["end_s"])) / 2.0, 3
        )
        scaled.append(row)
    return safe_segments(scaled, target_duration)


def load_reference_episode() -> tuple[list[dict[str, Any]], float, str] | None:
    """Load episode 1 as the canonical proportional-timestamp reference."""
    candidates = sorted(REFERENCE_EPISODE_DIR.glob("result*.json"))
    if not candidates:
        return None
    data = load_json(candidates[0])
    segments = data.get("semantic_segments")
    duration = float(data.get("duration_s") or 0.0)
    if not isinstance(segments, list) or not segments or duration <= 0:
        return None
    return (
        [dict(item) for item in segments],
        duration,
        str(data.get("episode_summary") or ""),
    )


class ActionPickDialog(QDialog):
    """乱序重复标注的动作选择框：Alt+数字 1-9 即选即关。

    列出模板预存动作（去重保序），Alt+数字或双击选中并 accept；
    Esc 取消（打点保留，段名不动）。模态 exec() 期间主窗口的
    WindowShortcut（含 Alt+数字）天然失效，选择由本弹窗拦截。
    """

    def __init__(
        self, prompt: str, actions: list[str], parent: "PrefillEditor | None" = None
    ):
        super().__init__(parent)
        self.setWindowTitle("选择动作")
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(prompt))
        self.action_list = QListWidget()
        for number, action in enumerate(actions, 1):
            item = QListWidgetItem(f"{number}. {action}")
            item.setData(Qt.UserRole, action)
            self.action_list.addItem(item)
        self.action_list.setCurrentRow(0)
        layout.addWidget(self.action_list)
        hint = QLabel(
            "按 Alt+1-9 直接选择（10 项以上用鼠标）；双击或选中后点确定；Esc 取消。"
        )
        layout.addWidget(hint)
        buttons = QHBoxLayout()
        ok_btn = QPushButton("确定")
        ok_btn.clicked.connect(self.accept)
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(self.reject)
        buttons.addStretch(1)
        buttons.addWidget(ok_btn)
        buttons.addWidget(cancel_btn)
        layout.addLayout(buttons)
        self.action_list.itemDoubleClicked.connect(lambda _: self.accept())

    def keyPressEvent(self, event) -> None:
        key = event.key()
        if (event.modifiers() & Qt.AltModifier) and Qt.Key_1 <= key <= Qt.Key_9:
            row = key - Qt.Key_1
            if row < self.action_list.count():
                self.action_list.setCurrentRow(row)
                self.accept()
                return
        super().keyPressEvent(event)

    def selected_action(self) -> str | None:
        item = self.action_list.currentItem()
        if item is None:
            return None
        return str(item.data(Qt.UserRole) or "").strip() or None


class PrefillEditor(Editor):
    def __init__(self):
        self._prefill_boundary_index = 0
        self._prefill_history: list[list[dict[str, Any]]] = []
        self._quick_marking = False
        self._quick_dynamic_used = False
        # 乱序重复标注子模式：空格打点 + 弹窗数字键选动作命名刚结束的段。
        self._repeat_marking = False
        # 片尾自动删除的触发阈值（秒）：最后一个打点距视频终点不超过该值。
        self._tail_cleanup_threshold = 10.0
        # 片尾自动清理总开关（面板复选框「自动清理片尾」），关闭时
        # cleanup_unstamped_tail 直接返回，模板多出的尾部片段全部保留。
        self._auto_tail_cleanup = True
        # Alt+数字 → 模板状态 映射（GUI 全局配置，跨 episode/模板）。
        self._alt_map: dict[str, str] = self.load_alt_map()
        # 删除多余尾部片段后，自动补写首尾四段的固定名称（拿板擦/移板擦
        # /收板擦/移瓶收臂），可由面板复选框关闭。
        self._auto_tail_names = True
        super().__init__()
        self.setWindowTitle("Subtask Splicer - 预装填版")
        # The base GUI assumes most of the window height is available to the
        # video.  The prefill dock adds controls below it, so a 420 px minimum
        # can force the timeline and slider to overlap the image on shorter
        # screens.  The canvas already preserves the full aspect ratio.
        self.video.setMinimumSize(240, 180)
        self.build_prefill_dock()
        self.quick_space_shortcut = QShortcut(QKeySequence("Space"), self)
        self.quick_space_shortcut.setContext(Qt.WindowShortcut)
        self.quick_space_shortcut.activated.connect(self.quick_mark_space)
        self.quick_space_shortcut.setEnabled(False)
        self.quick_insert_shortcut = QShortcut(QKeySequence("P"), self)
        self.quick_insert_shortcut.setContext(Qt.WindowShortcut)
        self.quick_insert_shortcut.activated.connect(self.quick_insert_task)
        self.quick_insert_shortcut.setEnabled(False)
        self.alt_mark_shortcuts: list[tuple[int, QShortcut]] = []
        for alt_number in range(1, 10):
            alt_sc = QShortcut(QKeySequence(f"Alt+{alt_number}"), self)
            alt_sc.setContext(Qt.WindowShortcut)
            alt_sc.activated.connect(partial(self.quick_mark_alt, alt_number))
            alt_sc.setEnabled(False)
            self.alt_mark_shortcuts.append((alt_number, alt_sc))
        self.save_shortcut = QShortcut(QKeySequence("Ctrl+S"), self)
        self.save_shortcut.setContext(Qt.WindowShortcut)
        self.save_shortcut.activated.connect(self.save)
        self.save_next_shortcut = QShortcut(QKeySequence("Ctrl+Return"), self)
        self.save_next_shortcut.setContext(Qt.WindowShortcut)
        self.save_next_shortcut.activated.connect(self.save_and_next)
        self.previous_segment_shortcut = QShortcut(
            QKeySequence(Qt.Key_Up), self
        )
        self.previous_segment_shortcut.setContext(Qt.WindowShortcut)
        self.previous_segment_shortcut.activated.connect(
            lambda: self.select_adjacent_segment(-1)
        )
        self.next_segment_shortcut = QShortcut(
            QKeySequence(Qt.Key_Down), self
        )
        self.next_segment_shortcut.setContext(Qt.WindowShortcut)
        self.next_segment_shortcut.activated.connect(
            lambda: self.select_adjacent_segment(1)
        )
        self.move_end_left_shortcut = QShortcut(
            QKeySequence(Qt.Key_Left), self
        )
        self.move_end_left_shortcut.setContext(Qt.WindowShortcut)
        self.move_end_left_shortcut.activated.connect(
            lambda: self.move_selected_segment_end(-1)
        )
        self.move_end_right_shortcut = QShortcut(
            QKeySequence(Qt.Key_Right), self
        )
        self.move_end_right_shortcut.setContext(Qt.WindowShortcut)
        self.move_end_right_shortcut.activated.connect(
            lambda: self.move_selected_segment_end(1)
        )
        self.segment_arrow_shortcuts = [
            self.previous_segment_shortcut,
            self.next_segment_shortcut,
            self.move_end_left_shortcut,
            self.move_end_right_shortcut,
        ]
        QApplication.instance().focusChanged.connect(
            self.update_segment_arrow_shortcuts
        )
        try:
            self.next_btn.clicked.disconnect()
        except TypeError:
            pass
        self.save_btn.setText("Save (Ctrl+S)")
        self.next_btn.setText("Save & Next (Ctrl+Enter)")
        self.next_btn.clicked.connect(self.save_and_next)
        self.load_template(0)
        self.auto_prefill_placeholder()

    def update_segment_arrow_shortcuts(self, _old, current) -> None:
        """Keep normal arrow-key editing inside text fields and combo boxes."""
        # The combo popup view is a QAbstractItemView; arrow keys there must
        # navigate the dropdown list, not move segment boundaries.
        text_editing = isinstance(
            current, (QLineEdit, QTextEdit, QComboBox, QAbstractItemView)
        )
        for shortcut in self.segment_arrow_shortcuts:
            shortcut.setEnabled(not text_editing)
        # Alt+数字 in an editable line edit would still fire a QShortcut, so
        # re-evaluate the quick-marking shortcuts whenever the focus moves.
        if getattr(self, "_quick_marking", False):
            self._set_quick_shortcuts(True)

    def select_adjacent_segment(self, direction: int) -> None:
        """Select the previous/next subtask with Up/Down."""
        if not self.subtasks:
            return
        current = self.timeline.selected
        if not (0 <= current < len(self.subtasks)):
            current = 0
        selected = max(0, min(len(self.subtasks) - 1, current + direction))
        self.select_segment(selected)
        if 0 <= selected < len(self.segment_rows):
            self.rows_scroll.ensureWidgetVisible(self.segment_rows[selected])
        if hasattr(self, "prefill_status"):
            self.prefill_status.setText(
                f"已选择 seg {selected + 1}/{len(self.subtasks)}："
                f"{self.subtasks[selected].get('current_subtask') or ''}"
            )

    def move_selected_segment_end(self, direction: int) -> None:
        """Move the selected segment end by one 3 Hz tick with Left/Right."""
        index = self.timeline.selected
        if not (0 <= index < len(self.subtasks)) or self.duration <= 0:
            return
        segment = self.subtasks[index]
        old_end = float(segment["end_s"])
        minimum = snap(float(segment["start_s"]) + 1 / 3)
        if index + 1 < len(self.subtasks):
            maximum = float(self.subtasks[index + 1]["end_s"]) - 1 / 3
        else:
            maximum = self.duration
        new_end = snap(old_end + direction / 3)
        new_end = max(minimum, min(maximum, new_end))
        new_end = round(new_end, 3)
        if abs(new_end - old_end) < 1e-6:
            if hasattr(self, "prefill_status"):
                self.prefill_status.setText(
                    f"seg {index + 1} 的尾戳已到可移动范围边界："
                    f"{old_end:.3f}s。"
                )
            return

        segment["end_s"] = new_end
        if index + 1 < len(self.subtasks):
            self.subtasks[index + 1]["start_s"] = new_end
        self.dirty = True
        self.update_segment_rows_light()
        self.seek_seconds(new_end)
        if hasattr(self, "prefill_status"):
            self.prefill_status.setText(
                f"seg {index + 1}/{len(self.subtasks)} 尾戳："
                f"{old_end:.3f}s → {new_end:.3f}s"
            )

    def refresh_all(self, selected: int | None = None) -> None:
        super().refresh_all(selected)
        self.update_current_episode_list_item()

    def update_current_episode_list_item(self) -> None:
        if not hasattr(self, "episode_list") or not self.data:
            return
        item = self.episode_list.currentItem()
        if item is None:
            return
        episode = str(item.data(Qt.UserRole) or self.data.get("episode_id") or "")
        status = str(
            self.data.get("status")
            or ("needs_review" if self.data.get("quality_flags") else "ok")
        )
        item.setText(f"{episode}  [{status}]  {len(self.subtasks)} seg")

    def build_prefill_dock(self) -> None:
        dock = QDockWidget("批量预装填 / 依次打时间边界", self)
        dock.setObjectName("PrefillDock")
        dock.setAllowedAreas(Qt.BottomDockWidgetArea | Qt.RightDockWidgetArea)
        dock.setMinimumHeight(190)
        dock.setMaximumHeight(400)
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # ── 分区一：模板（独立分区：可单独使用，或配合任意标注工作流） ──
        self.template_group = QGroupBox("模板")
        template_layout = QVBoxLayout(self.template_group)

        top = QGridLayout()
        self.prefill_template_combo = QComboBox()
        self.prefill_template_combo.setMaximumWidth(280)
        reference = load_reference_episode()
        reference_summary = reference[2] if reference is not None else ""
        if reference is not None:
            self.prefill_template_combo.addItem(
                f"Episode 1｜{reference_summary or '完整标注快照'}", "episode1"
            )
        for template_name in load_saved_templates():
            self.prefill_template_combo.addItem(
                template_name, f"saved:{template_name}"
            )
        if self.prefill_template_combo.count() == 0:
            self.prefill_template_combo.addItem(
                "暂无模板｜先加载并完成一个 episode，再保存为模板",
                "empty",
            )
        self.prefill_template_combo.currentIndexChanged.connect(self.load_template)
        top.addWidget(self.prefill_template_combo, 0, 0, 1, 2)
        self.prefill_save_btn = QPushButton("保存为模板")
        self.prefill_save_btn.clicked.connect(self.save_custom_template)
        top.addWidget(self.prefill_save_btn, 0, 2)
        self.prefill_delete_template_btn = QPushButton("删除模板")
        self.prefill_delete_template_btn.clicked.connect(
            self.delete_selected_template
        )
        top.addWidget(self.prefill_delete_template_btn, 0, 3)
        self.prefill_auto_checkbox = QCheckBox("占位 episode 加载时自动套用")
        self.prefill_auto_checkbox.setChecked(False)
        top.addWidget(self.prefill_auto_checkbox, 1, 0)
        self.prefill_apply_btn = QPushButton("套用模板并覆盖当前")
        self.prefill_apply_btn.clicked.connect(self.apply_template)
        top.addWidget(self.prefill_apply_btn, 1, 1, 1, 2)
        self.prefill_edit_text_btn = QPushButton("编辑模板文本…")
        self.prefill_edit_text_btn.clicked.connect(self.open_template_edit_dialog)
        top.addWidget(self.prefill_edit_text_btn, 1, 3)
        for column in range(4):
            top.setColumnStretch(column, 1)
        template_layout.addLayout(top)

        # 模板文本改为弹窗编辑：隐藏的 QTextEdit 仍是数据载体
        # （apply_template 直接读取），面板只显示摘要行 + 编辑按钮。
        self.prefill_text = QTextEdit()
        self.prefill_text.setVisible(False)
        template_layout.addWidget(self.prefill_text)

        # 模板概要与模板文本摘要合成一行短显示（限宽，不横贯整个面板；
        # 过长内容 QLineEdit 内部滚动，不影响数据完整性）。
        info_row = QHBoxLayout()
        info_row.addWidget(QLabel("概要"))
        self.prefill_summary = QLineEdit()
        self.prefill_summary.setMaximumWidth(280)
        info_row.addWidget(self.prefill_summary)
        info_row.addWidget(QLabel("文本"))
        self.prefill_template_summary = QLineEdit()
        self.prefill_template_summary.setReadOnly(True)
        self.prefill_template_summary.setMaximumWidth(280)
        self.prefill_template_summary.setPlaceholderText("点击编辑")
        info_row.addWidget(self.prefill_template_summary)
        info_row.addStretch(1)
        template_layout.addLayout(info_row)

        reuse_row = QGridLayout()
        self.prefill_next_ratio_btn = QPushButton("保存当前，并按相同比例套用到下一条")
        self.prefill_next_ratio_btn.clicked.connect(
            self.save_and_apply_ratios_to_next
        )
        reuse_row.addWidget(self.prefill_next_ratio_btn, 0, 0)
        reuse_help = QLabel(
            "适合同组 frame 接近的数据：复制名称、objects、target，"
            "并按视频总时长等比例缩放全部边界。"
        )
        reuse_help.setWordWrap(True)
        reuse_row.addWidget(reuse_help, 1, 0)
        template_layout.addLayout(reuse_row)
        layout.addWidget(self.template_group)

        # ── 分区二：粗标数据手动细化（原「按顺序快速标记」工作流） ──
        self.quick_group = QGroupBox("粗标数据手动细化")
        quick_layout = QGridLayout(self.quick_group)
        self.prefill_quick_btn = QPushButton("粗标数据手动细化")
        self.prefill_quick_btn.clicked.connect(self.start_or_stop_quick_marking)
        quick_layout.addWidget(self.prefill_quick_btn, 0, 0, 1, 2)
        self.prefill_tail_cleanup_check = QCheckBox("自动清理片尾")
        self.prefill_tail_cleanup_check.setChecked(self._auto_tail_cleanup)
        self.prefill_tail_cleanup_check.setToolTip(
            "勾选时：细化结束若最后一个打点距视频终点不超过右侧阈值，"
            "自动删除模板多出的尾部片段；取消勾选则全部保留。"
        )
        self.prefill_tail_cleanup_check.toggled.connect(
            self.set_auto_tail_cleanup
        )
        quick_layout.addWidget(self.prefill_tail_cleanup_check, 1, 0)
        self.prefill_tail_spin = QSpinBox()
        self.prefill_tail_spin.setRange(1, 60)
        self.prefill_tail_spin.setValue(int(self._tail_cleanup_threshold))
        self.prefill_tail_spin.setSuffix(" s")
        self.prefill_tail_spin.setToolTip(
            "删除尾部的触发阈值：最后一个空格打点位置距视频终点不超过"
            "该秒数才删除；打点位置更早时视为中途暂停，不删除。"
        )
        self.prefill_tail_spin.valueChanged.connect(
            self.set_tail_cleanup_threshold
        )
        quick_layout.addWidget(self.prefill_tail_spin, 1, 1)
        self.prefill_alt_map_btn = QPushButton("配置 Alt+数字…")
        self.prefill_alt_map_btn.clicked.connect(self.open_alt_map_dialog)
        quick_layout.addWidget(self.prefill_alt_map_btn, 2, 0)
        self.prefill_tail_names_check = QCheckBox("自动收尾命名")
        self.prefill_tail_names_check.setChecked(self._auto_tail_names)
        self.prefill_tail_names_check.setToolTip(
            "删除多余尾部片段后，自动把第一二段设为 拿板擦/移板擦、"
            "最后两段设为 收板擦/移瓶收臂。"
        )
        self.prefill_tail_names_check.toggled.connect(
            self.set_auto_tail_names
        )
        quick_layout.addWidget(self.prefill_tail_names_check, 2, 1)
        for column in range(2):
            quick_layout.setColumnStretch(column, 1)

        # ── 分区三：乱序重复标注（独立工作流） ──
        self.repeat_group = QGroupBox("乱序重复标注")
        repeat_layout = QVBoxLayout(self.repeat_group)
        self.prefill_repeat_btn = QPushButton("乱序重复标注")
        self.prefill_repeat_btn.clicked.connect(self.start_or_stop_repeat_marking)
        repeat_layout.addWidget(self.prefill_repeat_btn)
        repeat_help = QLabel(
            "空格打点（断点 = 前段终点 + 后段起点），"
            "弹窗用 Alt+数字 从模板动作中给刚结束的段命名；"
            "视频到结尾自动收尾。"
        )
        repeat_help.setWordWrap(True)
        repeat_layout.addWidget(repeat_help)
        repeat_layout.addStretch(1)

        workflows_row = QHBoxLayout()
        workflows_row.addWidget(self.quick_group, 3)
        workflows_row.addWidget(self.repeat_group, 2)
        layout.addLayout(workflows_row)

        # ── 通用：播放控制 ──
        playback = QGridLayout()
        playback.addWidget(QLabel("视频"), 0, 0)
        self.prefill_back_5_btn = QPushButton("⏪ -5s")
        self.prefill_back_5_btn.clicked.connect(lambda: self.jump_seconds(-5.0))
        playback.addWidget(self.prefill_back_5_btn, 0, 1)
        self.prefill_back_1_btn = QPushButton("◀ -1s")
        self.prefill_back_1_btn.clicked.connect(lambda: self.jump_seconds(-1.0))
        playback.addWidget(self.prefill_back_1_btn, 0, 2)
        self.prefill_play_btn = QPushButton("▶ 播放")
        self.prefill_play_btn.clicked.connect(self.toggle_play)
        playback.addWidget(self.prefill_play_btn, 0, 3)
        self.prefill_forward_1_btn = QPushButton("+1s ▶")
        self.prefill_forward_1_btn.clicked.connect(lambda: self.jump_seconds(1.0))
        playback.addWidget(self.prefill_forward_1_btn, 0, 4)
        self.prefill_forward_5_btn = QPushButton("+5s ⏩")
        self.prefill_forward_5_btn.clicked.connect(lambda: self.jump_seconds(5.0))
        playback.addWidget(self.prefill_forward_5_btn, 0, 5)
        playback.addWidget(QLabel("倍速"), 1, 1)
        self.prefill_speed_combo = QComboBox()
        for label, value in [
            ("0.5×", 0.5),
            ("1×", 1.0),
            ("2×", 2.0),
            ("4×", 4.0),
        ]:
            self.prefill_speed_combo.addItem(label, value)
        self.prefill_speed_combo.setCurrentIndex(1)
        self.prefill_speed_combo.currentIndexChanged.connect(
            self.update_playback_speed
        )
        playback.addWidget(self.prefill_speed_combo, 1, 2)
        playback.setColumnStretch(6, 1)
        layout.addLayout(playback)

        # ── 通用：手动打点行（顺序打边界的基础操作，工作流之外） ──
        manual_row = QHBoxLayout()
        self.prefill_start_btn = QPushButton("从第 1 段开始打边界")
        self.prefill_start_btn.clicked.connect(self.start_boundary_stamping)
        manual_row.addWidget(self.prefill_start_btn)
        self.prefill_mark_btn = QPushButton("记录边界 → 下一段")
        self.prefill_mark_btn.clicked.connect(self.mark_current_boundary)
        manual_row.addWidget(self.prefill_mark_btn)
        self.prefill_undo_btn = QPushButton("撤销上个边界")
        self.prefill_undo_btn.clicked.connect(self.undo_boundary)
        manual_row.addWidget(self.prefill_undo_btn)
        manual_row.addStretch(1)
        layout.addLayout(manual_row)

        self.prefill_quick_label = QLabel(
            "粗标数据手动细化未启动：Space 进入下一个已有 task；"
            "P 在当前时间插入新的未命名 task；"
            "Alt+数字 = 打点并写入映射状态。"
        )
        self.prefill_quick_label.setWordWrap(True)
        layout.addWidget(self.prefill_quick_label)

        self.prefill_status = QLabel("尚未装填模板")
        self.prefill_status.setWordWrap(True)
        layout.addWidget(self.prefill_status)

        dock_scroll = QScrollArea()
        dock_scroll.setWidgetResizable(True)
        dock_scroll.setFrameShape(QScrollArea.NoFrame)
        dock_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        dock_scroll.setWidget(panel)
        dock.setWidget(dock_scroll)
        self.addDockWidget(Qt.BottomDockWidgetArea, dock)
        self.prefill_dock = dock

    def playback_speed(self) -> float:
        if not hasattr(self, "prefill_speed_combo"):
            return 1.0
        return float(self.prefill_speed_combo.currentData() or 1.0)

    def update_playback_speed(self, _index: int = 0) -> None:
        if self.playing:
            interval = max(
                15,
                int(
                    1000
                    / max(0.1, self.video_fps)
                    / max(0.1, self.playback_speed())
                ),
            )
            self.timer.start(interval)

    def toggle_play(self) -> None:
        super().toggle_play()
        if self.playing:
            self.update_playback_speed()
        label = "⏸ 暂停" if self.playing else "▶ 播放"
        if hasattr(self, "prefill_play_btn"):
            self.prefill_play_btn.setText(label)
        if hasattr(self, "play_btn"):
            self.play_btn.setText("Pause" if self.playing else "Play/Pause")

    def jump_seconds(self, delta: float) -> None:
        self.show_frame_at(self.current_sec + delta)

    def start_or_stop_quick_marking(self) -> None:
        if self._quick_marking:
            # 任一模式进行中：按钮为停止键（先复位乱序标志再走统一复位）。
            if self._repeat_marking:
                self.finish_repeat_marking("已停止乱序标注。")
            else:
                self.stop_quick_marking("已停止粗标数据手动细化。")
            return
        if not self.subtasks:
            QMessageBox.information(
                self,
                "没有 task",
                "请先套用模板，或保留一个覆盖全视频的占位 task。",
            )
            return
        if self.cap is None or not self.cap.isOpened():
            QMessageBox.information(self, "视频未加载", "请先加载当前 episode 的视频。")
            return

        # 从当前选中的分段开始打点；已有边界（之前打过或模板比例）保持不变，
        # 不再重置为等分，也不从头开始。
        start_index = max(0, min(self.timeline.selected, len(self.subtasks) - 2))
        self._prefill_boundary_index = start_index
        self._prefill_history = []
        self._quick_marking = True
        self._quick_dynamic_used = False
        self._set_quick_shortcuts(True)
        self.prefill_quick_btn.setText("停止粗标数据手动细化")
        self.dirty = True
        self.refresh_all(selected=start_index)
        self.show_frame_at(float(self.subtasks[start_index]["start_s"]))
        if not self.playing:
            self.toggle_play()
        self.update_quick_mark_label()

    def quick_mark_space(self) -> None:
        if not self._quick_marking:
            return
        if self._repeat_marking:
            self.repeat_mark_space()
            return
        before = self._prefill_boundary_index
        self.mark_current_boundary()
        if not self._quick_marking:
            return  # 收尾路径（finish_marking_at_tail）已停止并给出提示
        if self._prefill_boundary_index == before:
            return
        if self._prefill_boundary_index >= len(self.subtasks) - 1:
            self._finish_quick_marking()
            return
        self.update_quick_mark_label()

    def template_actions(self) -> list[str]:
        """模板内预存的动作：当前加载模板的段名去重保序。"""
        seen: list[str] = []
        for segment in self._active_template_segments or []:
            name = str(segment.get("current_subtask") or "").strip()
            if name and name not in seen:
                seen.append(name)
        return seen

    def pick_action_dialog(self, prompt: str) -> str | None:
        """弹窗选模板动作；Esc 取消返回 None。"""
        dialog = ActionPickDialog(prompt, self.template_actions(), self)
        if dialog.exec_() != QDialog.Accepted:
            return None
        return dialog.selected_action()

    def start_or_stop_repeat_marking(self) -> None:
        """乱序重复标注模式：开启即正向播放，空格打点+暂停+弹窗命名。"""
        if self._quick_marking:
            # 任一模式进行中：按钮为停止键（先复位乱序标志再走统一收尾）。
            if self._repeat_marking:
                self.finish_repeat_marking("已停止乱序标注。")
            else:
                self.stop_quick_marking("已停止粗标数据手动细化。")
            return
        if not self._active_template_segments:
            QMessageBox.information(
                self,
                "没有模板动作",
                "请先加载模板（顶部模板列表），乱序标注从模板动作中选名字。",
            )
            return
        if not self.template_actions():
            QMessageBox.information(
                self, "模板没有动作", "当前模板没有可用的动作名。"
            )
            return
        if self.cap is None or not self.cap.isOpened():
            QMessageBox.information(self, "视频未加载", "请先加载当前 episode 的视频。")
            return
        if not self.subtasks:
            QMessageBox.information(
                self, "没有 task", "请先套用模板，或保留一个覆盖全视频的占位 task。"
            )
            return

        start_index = max(0, min(self.timeline.selected, len(self.subtasks) - 2))
        self._prefill_boundary_index = start_index
        self._prefill_history = []
        self._quick_marking = True
        self._repeat_marking = True
        self._set_quick_shortcuts(True)
        self.prefill_repeat_btn.setText("停止乱序标注")
        self.dirty = True
        self.refresh_all(selected=start_index)
        self.show_frame_at(float(self.subtasks[start_index]["start_s"]))
        if not self.playing:
            self.toggle_play()  # 开启后视频正向播放，直到空格打点
        self.update_quick_mark_label()

    def repeat_insert_boundary(self) -> None:
        """乱序模式：当前段已是最后一段时，打点并插入新段（自由分段）。

        实际动作段数可能多于模板段数：最后一个模板段被打点后不再拒绝，
        而是在其终点插入一个未命名新段并推进，后续空格继续分段。
        """
        index = self._prefill_boundary_index
        boundary = snap(self.current_sec)
        minimum = snap(float(self.subtasks[index]["start_s"]) + 1 / 3)
        maximum = snap(self.duration - 1 / 3)  # 插入后至少留 1/3s 给新段
        if boundary < minimum or boundary > maximum:
            QMessageBox.warning(
                self,
                "当前时间不可用",
                f"该断点需要位于 {minimum:.2f}s 至 {maximum:.2f}s；"
                f"当前是 {boundary:.2f}s。",
            )
            return
        self._prefill_history.append([dict(item) for item in self.subtasks])
        self.subtasks[index]["end_s"] = boundary
        inserted = {
            "start_s": boundary,
            "end_s": self.duration,
            "current_subtask": f"new subtask {len(self.subtasks) + 1}",
            "manipulated_objects": [],
            "target_location": None,
            "confidence": "manual",
            "boundary_reason": "repeat_mark_space",
            "evidence": "repeat-mode space breakpoint",
            "evidence_time_s": boundary,
        }
        self.subtasks.insert(index + 1, inserted)
        self.subtasks = safe_segments(self.subtasks, self.duration)
        self._prefill_boundary_index = index + 1
        self.dirty = True
        self.refresh_all(selected=self._prefill_boundary_index)
        self.save()

    def repeat_mark_space(self) -> None:
        """乱序模式空格：打点 → 暂停 → 弹窗 Alt+数字 命名刚结束的段 → 继续播放。

        断点即前一片段终点 + 下一片段起点；两个断点之间形成一个片段。
        弹窗取消（Esc）：断点保留，段名保持原样，可稍后手动改。
        """
        before = self._prefill_boundary_index
        if before >= len(self.subtasks) - 1:
            self.repeat_insert_boundary()  # 最后一段：打点并插入新段
        else:
            self.mark_current_boundary()
        if not self._quick_marking:
            return
        if self._prefill_boundary_index == before:
            return  # 打点失败（弹窗已提示）：不弹选择框
        was_playing = self.playing
        if was_playing:
            self.playing = False
            self.timer.stop()  # 暂停，确认刚结束片段的动作
        segment = self.subtasks[before]
        action = self.pick_action_dialog(
            f"第 {before + 1} 段（{float(segment['start_s']):.1f}s–"
            f"{float(segment['end_s']):.1f}s）的动作？"
        )
        if action:
            self._set_segment_state(before, action)
        if was_playing:
            self.toggle_play()  # 继续播放，进入下一片段
        if self._prefill_boundary_index >= len(self.subtasks) - 1:
            return  # 边界已全部打完；最后一段由收尾时命名
        self.update_quick_mark_label()

    def finish_repeat_marking(
        self, message: str = "", force: bool = True
    ) -> None:
        """乱序模式收尾（按钮停止 / 视频到结尾共用）。

        删除尾部多余模板段（force 跳过阈值判断：用户停止即明确结束），
        然后给最后一段命名：开启「自动收尾命名」时自动设为模板最后一个
        动作（不弹窗）；否则弹窗用 Alt+数字 选择。
        """
        if not self._quick_marking or not self._repeat_marking:
            return
        self._repeat_marking = False  # 先复位，防 video_tick 重入
        if hasattr(self, "prefill_repeat_btn"):
            self.prefill_repeat_btn.setText("乱序重复标注")
        removed = 0
        if self.subtasks:
            removed = self.cleanup_unstamped_tail(
                rename_tail=False, force=force
            )
            index = min(self._prefill_boundary_index, len(self.subtasks) - 1)
            actions = self.template_actions()
            if self._auto_tail_names and actions:
                # 自动收尾命名：不弹窗，最后一段 = 模板最后一个动作。
                self._set_segment_state(index, actions[-1])
            else:
                action = self.pick_action_dialog(
                    f"最后一段（第 {index + 1} 段，持续到视频结尾）的动作？"
                )
                if action:
                    self._set_segment_state(index, action)
        if removed:
            message += f" 已删除模板多出的尾部片段 {removed} 个。"
        self.stop_quick_marking(message, cleanup=False)

    def quick_insert_task(self) -> None:
        """Split at the current frame and insert an unnamed dynamic task."""
        if not self._quick_marking or not self.subtasks:
            return
        if self._repeat_marking:
            return  # 乱序模式禁用（快捷键已禁用，双保险）
        index = min(self._prefill_boundary_index, len(self.subtasks) - 1)
        boundary = snap(self.current_sec)
        minimum = snap(float(self.subtasks[index]["start_s"]) + 1 / 3)
        future_count = len(self.subtasks) - index - 1
        # After insertion there is one more segment in the remaining duration.
        maximum = snap(self.duration - (future_count + 1) / 3)
        if boundary < minimum or boundary > maximum:
            QMessageBox.warning(
                self,
                "当前时间不可插入",
                f"新边界需要位于 {minimum:.2f}s 至 {maximum:.2f}s；"
                f"当前是 {boundary:.2f}s。",
            )
            return

        self._prefill_history.append([dict(item) for item in self.subtasks])
        self.subtasks[index]["end_s"] = boundary
        inserted = {
            "start_s": boundary,
            "end_s": self.duration,
            "current_subtask": f"new subtask {len(self.subtasks) + 1}",
            "manipulated_objects": [],
            "target_location": None,
            "confidence": "manual",
            "boundary_reason": "quick_insert_key_p",
            "evidence": "P-key dynamic task insertion",
            "evidence_time_s": boundary,
        }
        self.subtasks.insert(index + 1, inserted)

        remaining_rows = len(self.subtasks) - index - 1
        remaining_duration = self.duration - boundary
        for offset, row_index in enumerate(range(index + 1, len(self.subtasks))):
            start = boundary + remaining_duration * offset / remaining_rows
            end = boundary + remaining_duration * (offset + 1) / remaining_rows
            self.subtasks[row_index]["start_s"] = snap(start)
            self.subtasks[row_index]["end_s"] = (
                self.duration
                if row_index == len(self.subtasks) - 1
                else snap(end)
            )

        self.subtasks = safe_segments(self.subtasks, self.duration)
        self._prefill_boundary_index = index + 1
        self._quick_dynamic_used = True
        self.dirty = True
        self.refresh_all(selected=self._prefill_boundary_index)
        self.prefill_status.setText(
            f"P 插入成功：{boundary:.2f}s，新建 "
            f"“{self.subtasks[self._prefill_boundary_index]['current_subtask']}”。"
        )
        self.update_quick_mark_label()

    def update_quick_mark_label(self) -> None:
        index = self._prefill_boundary_index
        count = len(self.subtasks)
        if not (0 <= index < count):
            return
        if self._repeat_marking:
            self.prefill_quick_label.setText(
                f"乱序标注中：第 {index + 1}/{count} 段"
                f"“{self.subtasks[index]['current_subtask']}”。"
                "Space = 打点并暂停，弹窗 Alt+数字 选择动作后继续播放；"
                "Esc 保留断点不命名。"
            )
            return
        self.prefill_quick_label.setText(
            f"粗标数据手动细化中：当前第 {index + 1}/{count} 段 "
            f"“{self.subtasks[index]['current_subtask']}”。"
            "Space = 进入下一个已有 task；P = 插入新的未命名 task；"
            "Alt+数字 = 打点并写入映射状态。视频不会暂停。"
        )

    def cleanup_unstamped_tail(
        self,
        rename_tail: bool | None = None,
        force: bool = False,
    ) -> int:
        """打点结束：删除模板多出的尾部片段（未打点标记且未被选中）。

        空格打点按顺序推进 _prefill_boundary_index：0..index-1 已打点标记；
        index 是当前选中但未打标的片段——人不会给最后一段打终点（它的
        终点天然是视频结尾），所以 index 保留并延伸到视频结尾；只删除
        index 之后真正多余的模板片段。

        触发条件：最后一个打点位置（index 片段起点）距视频终点不超过
        阈值（面板「自动清理片尾」+ 秒数），才认为动作已结束、尾部是
        多余的；打点位置还很早时可能只是中途暂停，不删除。一个点都没
        打过（index==0）或边界已全部打完（index >= count-1）同样不删。

        rename_tail：None → 沿用面板「自动收尾命名」开关（顺序模式）；
        False → 不做首尾命名（乱序模式，vase 固定动作在此不适用）。
        force：True → 跳过阈值判断（乱序模式收尾：用户停止/视频到结尾
        即明确结束，尾部模板段多余）；False → 阈值判断（顺序模式）。
        """
        count = len(self.subtasks)
        index = self._prefill_boundary_index
        if not self._auto_tail_cleanup:
            return 0
        if index <= 0 or index >= count - 1:
            return 0
        last_stamp = float(self.subtasks[index]["start_s"])
        if not force and self.duration - last_stamp >= self._tail_cleanup_threshold:
            return 0
        removed = count - index - 1
        self._prefill_history.append([dict(item) for item in self.subtasks])
        if removed > 0:
            del self.subtasks[index + 1:]
        self.subtasks[index]["end_s"] = self.duration
        # 删除尾部后固定收尾描述：开头两段=拿板擦/移板擦，最后一段=
        # 移瓶收臂，倒数第二段=收板擦。收尾时开头/结尾通常没有打点，
        # 模板尾部被删后名称未必匹配实际动作，按 vase 流程的固定动作
        # 补写（与模板一致的名字，可被 replace_char_keys 展开）。
        # 段数极少（<4）时首尾规则重叠，后设置的（尾部）覆盖前者。
        # 面板复选框「自动收尾命名」可关闭本行为；乱序模式传 rename_tail=False。
        if rename_tail if rename_tail is not None else self._auto_tail_names:
            self.subtasks[0]["current_subtask"] = "拿板擦"
            if len(self.subtasks) > 1:
                self.subtasks[1]["current_subtask"] = "移板擦"
            self.subtasks[index]["current_subtask"] = "移瓶收臂"
            if index - 1 >= 0:
                self.subtasks[index - 1]["current_subtask"] = "收板擦"
        self.subtasks = safe_segments(self.subtasks, self.duration)
        self._prefill_boundary_index = index
        self.dirty = True
        self.refresh_all(selected=index)
        self.save()
        return removed

    def set_tail_cleanup_threshold(self, value: int) -> None:
        """片尾删除阈值由面板 QSpinBox 调节。"""
        self._tail_cleanup_threshold = float(value)

    def set_auto_tail_cleanup(self, checked: bool) -> None:
        """片尾自动清理总开关：关闭时不删尾部片段，阈值 spin 同步禁用。"""
        self._auto_tail_cleanup = bool(checked)
        if hasattr(self, "prefill_tail_spin"):
            self.prefill_tail_spin.setEnabled(self._auto_tail_cleanup)

    def set_auto_tail_names(self, checked: bool) -> None:
        """删除尾部后的自动首尾命名由面板复选框开关。"""
        self._auto_tail_names = bool(checked)

    def load_alt_map(self) -> dict[str, str]:
        """读取 Alt+数字 → 状态 映射。文件缺失/损坏 → {}。

        key 限定 "1".."9"（Alt+1..9），value 去掉首尾空白。
        """
        try:
            data = json.loads(ALT_MAP_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
        if not isinstance(data, dict):
            return {}
        valid_keys = {str(n) for n in range(1, 10)}
        return {
            str(k): str(v).strip()
            for k, v in data.items()
            if str(k) in valid_keys and str(v).strip()
        }

    def save_alt_map(self) -> None:
        """把 self._alt_map 写入 prefill_alt_map.json（空映射也写 {}）。"""
        ALT_MAP_PATH.write_text(
            json.dumps(self._alt_map, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    def _set_quick_shortcuts(self, enabled: bool) -> None:
        """统一开关快速标记的全部快捷键（Space / P / Alt+1..9）。

        焦点在文本编辑控件（行名下拉框、文本框等）时禁用——editable
        combo 的 lineEdit 吞不掉 Alt+组合键，不禁用的话编辑名字时误按
        Alt+N 会触发 refresh_all 重建行、销毁正在编辑的文本。
        """
        focus = QApplication.focusWidget()
        text_editing = isinstance(
            focus, (QLineEdit, QTextEdit, QComboBox, QAbstractItemView)
        )
        # 乱序重复模式下 P（插入动态段）与 Alt+数字（顺序打点命名）
        # 语义冲突，一律禁用，只保留 Space。
        repeat = getattr(self, "_repeat_marking", False)
        self.quick_space_shortcut.setEnabled(enabled and not text_editing)
        self.quick_insert_shortcut.setEnabled(
            enabled and not text_editing and not repeat
        )
        for number, shortcut in self.alt_mark_shortcuts:
            shortcut.setEnabled(
                enabled
                and not text_editing
                and not repeat
                and bool(self._alt_map.get(str(number)))
            )

    def _finish_quick_marking(self) -> None:
        """全部段间边界完成后的收尾（Space 与 Alt 共用）。播放继续，不删尾部。"""
        self._quick_marking = False
        self._set_quick_shortcuts(False)
        self.prefill_quick_btn.setText("粗标数据手动细化")
        self.prefill_quick_label.setText(
            "全部段间边界已完成。最后一段默认持续到视频结尾；"
            "播放会继续，可检查后保存。"
        )

    def _set_segment_state(
        self, index: int, state: str, message: bool = False
    ) -> None:
        """把当前段状态写入 subtasks 并落盘；行显示同步（不重建行）。"""
        if self.subtasks[index].get("current_subtask") == state:
            return  # 已一致：跳过写入与第二次 save
        self.subtasks[index]["current_subtask"] = state
        self.dirty = True
        self.update_segment_rows_light()
        self.save()
        if message:
            self.prefill_status.setText(
                f"最后一段状态已设为“{state}”，数据已保存。"
            )

    def quick_mark_alt(self, number: int) -> None:
        """Alt+数字：打点当前段边界 + 把状态写入当前段 + 推进到下一段。

        仅粗标数据手动细化模式启动期间生效。最后一段没有可打点的边界，只写状态。
        打点未成功（时间越界，弹窗已提示）时保持状态不变。
        """
        if not self._quick_marking or not self.subtasks:
            return
        if self._repeat_marking:
            return  # 乱序模式禁用（快捷键已禁用，双保险）
        state = self._alt_map.get(str(number))
        if not state:
            return
        before = self._prefill_boundary_index
        count = len(self.subtasks)
        if before >= count - 1:
            # 最后一段：只写状态，不收尾（与 Space 在结尾处 no-op 一致，
            # 标记模式保持启动，由按钮/视频结束收尾）。
            self._set_segment_state(before, state, message=True)
            return
        self.mark_current_boundary()
        if self._prefill_boundary_index == before:
            return  # 打点未成功：不改状态、不写名字
        # 打点成功：把状态写到刚打点的这段（before）。refresh_all 已在
        # mark_current_boundary 内重建行，update_segment_rows_light 此时
        # 调用安全（新行无焦点）。
        self._set_segment_state(before, state)
        if self._prefill_boundary_index >= count - 1:
            self._finish_quick_marking()  # 最后边界打点后与 Space 一样收尾
        else:
            self.update_quick_mark_label()

    def open_alt_map_dialog(self) -> None:
        """配置 Alt+数字 → 状态 映射的模态对话框，确定后持久化并同步快捷键。"""
        dialog = QDialog(self)
        dialog.setWindowTitle("配置 Alt+数字 映射")
        layout = QVBoxLayout(dialog)
        grid = QGridLayout()
        combos: list[tuple[int, QComboBox]] = []
        for i, n in enumerate(range(1, 10)):
            grid.addWidget(QLabel(f"Alt+{n}"), i, 0)
            combo = QComboBox()
            combo.setEditable(True)
            combo.setInsertPolicy(QComboBox.NoInsert)
            combo.addItems(ACTION_KEYS)
            combo.setCurrentText(self._alt_map.get(str(n), ""))
            combo.setToolTip("选择模板动作；清空文本 = 该数字不映射。")
            grid.addWidget(combo, i, 1)
            combos.append((n, combo))
        layout.addLayout(grid)

        fill_btn = QPushButton("按 MAPPING 顺序填入 Alt+1..7")
        fill_btn.clicked.connect(
            lambda: [
                combo.setCurrentText(ACTION_KEYS[i] if i < len(ACTION_KEYS) else "")
                for i, (_, combo) in enumerate(combos)
            ]
        )
        layout.addWidget(fill_btn)

        hint = QLabel(
            "Alt+N = 打点当前段边界 + 把状态写入当前段 + 推进到下一段。"
            "仅粗标数据手动细化模式（空格打点）启动期间生效。"
            "写入的是缩句 key，之后由 replace_char_keys.py 展开为英文。"
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)

        buttons = QHBoxLayout()
        ok_btn = QPushButton("确定")
        cancel_btn = QPushButton("取消")
        buttons.addStretch(1)
        buttons.addWidget(ok_btn)
        buttons.addWidget(cancel_btn)
        layout.addLayout(buttons)
        ok_btn.clicked.connect(dialog.accept)
        cancel_btn.clicked.connect(dialog.reject)

        if dialog.exec_() != QDialog.Accepted:
            return
        self._alt_map = {
            str(n): combo.currentText().strip()
            for n, combo in combos
            if combo.currentText().strip()
        }
        try:
            self.save_alt_map()
        except Exception as exc:
            QMessageBox.warning(self, "映射保存失败", str(exc))
            return
        if self._quick_marking:
            # 快速标记进行中：即时同步快捷键 enabled 状态。
            self._set_quick_shortcuts(True)
        self.prefill_status.setText(
            f"已保存 Alt 映射：{len(self._alt_map)} 个数字快捷键。"
        )

    def stop_quick_marking(
        self,
        message: str = "",
        cleanup: bool = True,
        rename_tail: bool | None = None,
    ) -> None:
        removed = 0
        if self._quick_marking and cleanup:
            removed = self.cleanup_unstamped_tail(rename_tail=rename_tail)
        self._quick_marking = False
        if hasattr(self, "alt_mark_shortcuts"):
            self._set_quick_shortcuts(False)
        if hasattr(self, "prefill_quick_btn"):
            self.prefill_quick_btn.setText(
                "粗标数据手动细化"
            )
        if self.playing:
            self.playing = False
            self.timer.stop()
        if hasattr(self, "prefill_play_btn"):
            self.prefill_play_btn.setText("▶ 播放")
        if hasattr(self, "play_btn"):
            self.play_btn.setText("Play/Pause")
        if message and hasattr(self, "prefill_quick_label"):
            if removed:
                message = (
                    f"{message} 已删除模板多出的尾部片段 {removed} 个；"
                    f"当前片段结束于视频结尾 {self.duration:.2f}s。"
                )
            self.prefill_quick_label.setText(message)

    def open_template_edit_dialog(self) -> None:
        """单击「编辑模板文本…」打开模态弹窗编辑，确定写回、取消丢弃。"""
        dialog = QDialog(self)
        dialog.setWindowTitle("编辑模板文本")
        layout = QVBoxLayout(dialog)
        editor = QTextEdit()
        editor.setPlainText(self.prefill_text.toPlainText())
        editor.setMinimumSize(560, 300)
        layout.addWidget(editor)
        hint = QLabel(
            "每行格式：subtask | objects（逗号分隔）| target。"
            "模板同时保存完整时间比例；应用时直接覆盖当前分段。"
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        buttons = QHBoxLayout()
        ok_btn = QPushButton("确定")
        cancel_btn = QPushButton("取消")
        buttons.addStretch(1)
        buttons.addWidget(ok_btn)
        buttons.addWidget(cancel_btn)
        layout.addLayout(buttons)
        ok_btn.clicked.connect(dialog.accept)
        cancel_btn.clicked.connect(dialog.reject)
        if dialog.exec_() != QDialog.Accepted:
            return
        self.prefill_text.setPlainText(editor.toPlainText())
        self._update_template_summary()
        self.prefill_status.setText(
            "模板文本已更新，可点击“套用模板并覆盖当前”。"
        )

    def _update_template_summary(self) -> None:
        """根据 prefill_text 内容刷新摘要行（行数与首行名称）。"""
        if not hasattr(self, "prefill_template_summary"):
            return
        lines = [
            ln for ln in self.prefill_text.toPlainText().splitlines() if ln.strip()
        ]
        if not lines:
            self.prefill_template_summary.setText("空模板")
            return
        first = lines[0].split("|")[0].strip()
        self.prefill_template_summary.setText(
            f"{len(lines)} 行 · 首行：{first or '(空名称)'}"
        )

    def video_tick(self) -> None:
        was_playing = self.playing
        super().video_tick()
        if was_playing and not self.playing:
            if hasattr(self, "prefill_play_btn"):
                self.prefill_play_btn.setText("▶ 播放")
            if hasattr(self, "play_btn"):
                self.play_btn.setText("Play/Pause")
            if self._quick_marking:
                if self._repeat_marking:
                    # 乱序模式播放到结尾：自动触发收尾——自动收尾命名开启
                    # 时不弹窗（最后一段 = 模板最后一个动作），否则弹窗选择。
                    self.finish_repeat_marking(
                        "视频已到结尾，乱序标注结束，数据已自动保存。"
                    )
                elif self._quick_dynamic_used:
                    self.stop_quick_marking(
                        "视频已结束，P 动态分段已完成，数据已自动保存。"
                        "现在可在右侧逐个修改 new subtask 名称。"
                    )
                    self.save()
                else:
                    # 打点模式播放到结尾：stop 会自动删除未打点标记的
                    # 尾部片段（若已打完所有边界则保留）并保存。
                    self.stop_quick_marking(
                        "视频已到结尾，打点结束，数据已自动保存。"
                    )

    def load_template(self, index: int) -> None:
        if not hasattr(self, "prefill_template_combo"):
            return
        name = self.prefill_template_combo.itemText(index)
        key = self.prefill_template_combo.itemData(index)
        segments: list[dict[str, Any]]
        source_duration: float
        if key == "empty":
            self._active_template_segments = []
            self._active_template_duration = 0.0
            self.prefill_text.clear()
            self._update_template_summary()
            self.prefill_summary.clear()
            self.prefill_status.setText(
                "当前没有完整模板。加载数据并完成一个 episode 后，"
                "点击顶部“保存为模板”。"
            )
            return
        if isinstance(key, str) and key.startswith("saved:"):
            try:
                template_name = key.removeprefix("saved:")
                data = load_saved_templates()[template_name]
                segments = [dict(item) for item in (data.get("segments") or [])]
                source_duration = float(data.get("source_duration") or 0.0)
                summary = str(data.get("summary") or "")
            except Exception as exc:
                QMessageBox.warning(self, "模板读取失败", str(exc))
                return
            if not segments or source_duration <= 0:
                QMessageBox.warning(
                    self,
                    "旧模板没有时间比例",
                    "这个模板只保存了文字，没有完整时间戳。"
                    "请在一个已完成的 episode 上点击“把当前 episode 保存为模板”。",
                )
                return
        elif key == "episode1":
            reference = load_reference_episode()
            if reference is None:
                QMessageBox.warning(self, "模板读取失败", "找不到 episode 1 标注。")
                return
            segments, source_duration, summary = reference
        else:
            return
        lines = [
            " | ".join(
                [
                    str(segment.get("current_subtask") or ""),
                    ", ".join(
                        str(item)
                        for item in (segment.get("manipulated_objects") or [])
                    ),
                    str(segment.get("target_location") or ""),
                ]
            )
            for segment in segments
        ]
        self._active_template_segments = segments
        self._active_template_duration = source_duration
        self.prefill_text.setPlainText("\n".join(lines))
        self._update_template_summary()
        self.prefill_summary.setText(summary)
        self.prefill_status.setText(
            f"已加载模板：{name}（{len(lines)} 段，参考时长 "
            f"{source_duration:.2f}s，包含完整时间比例）"
        )

    def is_random_placeholder(self) -> bool:
        if not self.data or len(self.subtasks) != 1:
            return False
        label = str(self.subtasks[0].get("current_subtask") or "")
        flags = self.data.get("quality_flags") or []
        return (
            label.startswith("reviewer06-")
            or "random_placeholder_label" in flags
            or self.data.get("status") == "needs_human_review_placeholder"
        )

    def load_selected_episode(self, cur, prev=None):
        if self._quick_marking:
            self.stop_quick_marking(cleanup=False)
        super().load_selected_episode(cur, prev)
        self._prefill_boundary_index = 0
        self._prefill_history = []
        if hasattr(self, "prefill_auto_checkbox"):
            self.auto_prefill_placeholder()

    def auto_prefill_placeholder(self) -> None:
        if (
            hasattr(self, "prefill_auto_checkbox")
            and self.prefill_auto_checkbox.isChecked()
            and self.is_random_placeholder()
        ):
            self.apply_template(confirm=False)

    def apply_template(self, _checked=False, confirm: bool = True) -> None:
        if self._quick_marking:
            self.stop_quick_marking(cleanup=False)
        if not self.data or self.duration <= 0:
            QMessageBox.information(self, "尚未加载 episode", "请先选择一个 episode。")
            return
        source_segments = getattr(self, "_active_template_segments", None)
        source_duration = float(
            getattr(self, "_active_template_duration", 0.0) or 0.0
        )
        if not source_segments or source_duration <= 0:
            QMessageBox.warning(self, "模板无时间比例", "请重新选择一个完整标注模板。")
            return
        try:
            rows = parse_template(self.prefill_text.toPlainText())
            if len(rows) != len(source_segments):
                raise ValueError(
                    f"模板快照有 {len(source_segments)} 段，但文本区现在有 "
                    f"{len(rows)} 段。可以改名称，但不能增删行；如需改变段数，"
                    "请先在当前 episode 完成标注，再保存成新模板。"
                )
            generated = scale_segments_by_ratios(
                source_segments,
                source_duration,
                self.duration,
            )
            for segment, template_row in zip(generated, rows):
                segment["current_subtask"] = template_row["current_subtask"]
                segment["manipulated_objects"] = template_row[
                    "manipulated_objects"
                ]
                segment["target_location"] = template_row["target_location"]
        except Exception as exc:
            QMessageBox.warning(self, "模板无效", str(exc))
            return
        self.subtasks = generated
        summary = self.prefill_summary.text().strip()
        if summary:
            self.summary.setPlainText(summary)
        self.dirty = True
        self._prefill_boundary_index = 0
        self._prefill_history = []
        self.refresh_all(selected=0)
        template_name = self.prefill_template_combo.currentText()
        self.prefill_status.setText(
            f"已用“{template_name}”直接覆盖当前，共 {len(self.subtasks)} 段；"
            f"时间已从参考时长 {source_duration:.2f}s 按比例缩放到 "
            f"{self.duration:.2f}s。"
        )

    def start_boundary_stamping(self) -> None:
        if len(self.subtasks) < 2:
            QMessageBox.information(self, "没有足够分段", "请先一键生成至少两个分段。")
            return
        self._prefill_boundary_index = 0
        self._prefill_history = []
        self.select_segment(0)
        self.prefill_status.setText(
            f"正在标第 1 段结束时间：{self.subtasks[0]['current_subtask']}。"
            "定位视频后点击“记录当前边界”。"
        )

    def _distribute_remainder(self, index: int) -> None:
        """把 index 之后的剩余片段在 [index 的 end_s, 视频结尾] 内均匀分布。"""
        count = len(self.subtasks)
        remaining = count - index - 1
        if remaining <= 0:
            return
        boundary = float(self.subtasks[index]["end_s"])
        remaining_duration = self.duration - boundary
        for offset, row_index in enumerate(range(index + 1, count)):
            start = boundary + remaining_duration * offset / remaining
            end = boundary + remaining_duration * (offset + 1) / remaining
            self.subtasks[row_index]["start_s"] = snap(start)
            self.subtasks[row_index]["end_s"] = (
                self.duration if row_index == count - 1 else snap(end)
            )
        self.subtasks = safe_segments(self.subtasks, self.duration)

    def mark_current_boundary(self) -> None:
        count = len(self.subtasks)
        index = self._prefill_boundary_index
        if count < 2 or index >= count - 1:
            self.prefill_status.setText("所有段间边界都已记录；请检查时间轴后保存 JSON。")
            return
        boundary = snap(self.current_sec)
        minimum = snap(float(self.subtasks[index]["start_s"]) + 1 / 3)
        remaining = count - index - 1
        maximum = snap(self.duration - remaining / 3)
        if boundary < minimum or boundary > maximum:
            QMessageBox.warning(
                self,
                "当前时间不可用",
                f"该边界需要位于 {minimum:.2f}s 至 {maximum:.2f}s；"
                f"当前是 {boundary:.2f}s。",
            )
            return

        self._prefill_history.append([dict(item) for item in self.subtasks])
        self.subtasks[index]["end_s"] = boundary
        # Keep past stamps fixed and redistribute only the unmarked remainder.
        self._distribute_remainder(index)
        self.dirty = True
        self._prefill_boundary_index += 1
        next_index = self._prefill_boundary_index
        self.refresh_all(selected=next_index)
        self.save()
        if next_index >= count - 1:
            self.prefill_status.setText(
                f"已记录最后一个段间边界（{boundary:.2f}s），数据已自动保存。"
                "最后一段默认结束于视频结尾；检查后点击 Save JSON 收尾。"
            )
        else:
            self.prefill_status.setText(
                f"已记录边界 {index + 1}/{count - 1}：{boundary:.2f}s，"
                "数据已自动保存。"
                f"现在定位第 {next_index + 1} 段的结束时间："
                f"{self.subtasks[next_index]['current_subtask']}。"
            )

    def undo_boundary(self) -> None:
        if not self._prefill_history:
            self.prefill_status.setText("没有可撤销的预装填边界。")
            return
        self.subtasks = self._prefill_history.pop()
        self._prefill_boundary_index = max(0, self._prefill_boundary_index - 1)
        self.dirty = True
        self.refresh_all(selected=self._prefill_boundary_index)
        self.prefill_status.setText(
            f"已撤销。请重新记录第 {self._prefill_boundary_index + 1} 段的结束时间。"
        )

    def save(self) -> bool:
        """Save silently; report success in the prefill status instead of a dialog."""
        if not self.data or not self.result_path:
            return False
        try:
            self.subtasks[:] = safe_segments(self.subtasks, self.duration)
            summary = self.summary.toPlainText().strip()
            set_subtasks(
                self.data,
                self.subtask_storage_path,
                self.subtasks,
                summary,
            )
            if self.subtask_storage_path == "parsed.subtasks" and AUDIT is not None:
                parsed = (
                    self.data.get("parsed")
                    if isinstance(self.data.get("parsed"), dict)
                    else {}
                )
                parsed = AUDIT.normalize_parsed(parsed)
                dataset = self.data.get("dataset") or (
                    self.dataset_combo.currentData() or ""
                )
                flags = AUDIT.quality_flags(
                    parsed,
                    self.duration,
                    AUDIT.long_segment_threshold_s(dataset),
                    dataset=dataset,
                )
                self.data["quality_flags"] = flags
                self.data["status"] = "ok" if not flags else "needs_review"
                self.data["parsed"] = parsed
                saved_count = len(parsed.get("subtasks") or [])
            else:
                self.data["status"] = "manual_edited"
                placeholder_flags = {
                    "manual_segmentation_required",
                    "random_placeholder_label",
                }
                self.data["quality_flags"] = [
                    flag
                    for flag in (self.data.get("quality_flags") or [])
                    if flag not in placeholder_flags
                ]
                saved_count = len(self.subtasks)
            self.data["manual_subtask_edit"] = {
                "edited_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "editor": "subtask_editor_gui_prefill.py",
                "storage_path": self.subtask_storage_path,
                "subtask_count": saved_count,
                "backup_created": False,
            }
            write_json(self.result_path, self.data)
            self.dirty = False
            self.update_current_episode_list_item()
            saved_at = time.strftime("%H:%M:%S")
            if hasattr(self, "prefill_status"):
                self.prefill_status.setText(
                    f"✓ {saved_at} 已自动保存：{self.result_path.parent.name}，"
                    f"共 {saved_count} 段。"
                )
            return True
        except Exception as exc:
            QMessageBox.critical(self, "Save failed", str(exc))
            return False

    def save_and_next(self) -> None:
        if self._quick_marking:
            self.stop_quick_marking()
        current_row = self.episode_list.currentRow()
        if current_row < 0:
            return
        if not self.save():
            return
        if current_row + 1 >= self.episode_list.count():
            self.prefill_status.setText("✓ 当前已保存；这已经是最后一个 episode。")
            return
        self.episode_list.setCurrentRow(current_row + 1)
        self.prefill_status.setText(
            f"✓ 上一个 episode 已自动保存；已进入第 "
            f"{current_row + 2}/{self.episode_list.count()} 条。"
        )

    def save_and_apply_ratios_to_next(self) -> None:
        if not self.data or not self.result_path or not self.subtasks:
            QMessageBox.information(self, "尚未完成当前条", "请先完成当前 episode 的分段。")
            return
        current_row = self.episode_list.currentRow()
        if current_row < 0 or current_row + 1 >= self.episode_list.count():
            QMessageBox.information(self, "已经是最后一条", "当前没有下一个 episode。")
            return

        source_duration = self.duration
        source_segments = [dict(item) for item in self.subtasks]
        source_summary = self.summary.toPlainText().strip()

        if not self.save():
            return

        self.episode_list.setCurrentRow(current_row + 1)
        if not self.data or self.duration <= 0:
            QMessageBox.warning(self, "下一条加载失败", "无法读取下一个 episode。")
            return
        try:
            self.subtasks = scale_segments_by_ratios(
                source_segments,
                source_duration,
                self.duration,
            )
        except Exception as exc:
            QMessageBox.warning(self, "比例套用失败", str(exc))
            return
        if source_summary:
            self.summary.setPlainText(source_summary)
        self.dirty = True
        self._prefill_boundary_index = 0
        self._prefill_history = []
        self.refresh_all(selected=0)
        self.prefill_status.setText(
            f"已从上一条复制 {len(self.subtasks)} 段，并按新视频 "
            f"{self.duration:.2f}s 等比例缩放时间戳。检查后可继续调整；"
            "若仍合适，再点同一按钮传给下一条。"
        )

    def save_custom_template(self) -> None:
        if not self.data or self.duration <= 0 or not self.subtasks:
            QMessageBox.information(
                self, "尚无完整标注", "请先完成当前 episode 的分段。"
            )
            return
        try:
            segments = safe_segments(
                [dict(item) for item in self.subtasks],
                self.duration,
            )
            summary = self.summary.toPlainText().strip()
            default_name = summary or (
                str(self.data.get("episode_id") or self.result_path.parent.name)
            )
            template_name, ok = QInputDialog.getText(
                self,
                "命名标注模板",
                "模板名称（默认使用当前 Summary）：",
                text=default_name,
            )
            template_name = template_name.strip()
            if not ok or not template_name:
                return
            templates = load_saved_templates()
            if template_name in templates:
                answer = QMessageBox.question(
                    self,
                    "覆盖同名模板？",
                    f"模板“{template_name}”已经存在，是否用当前 episode 覆盖它？",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if answer != QMessageBox.Yes:
                    return
            templates[template_name] = {
                "summary": summary,
                "source_duration": self.duration,
                "segments": segments,
                "source_episode": str(
                    self.data.get("episode_id") or self.result_path.parent.name
                ),
                "lines": [
                    " | ".join(
                        [
                            str(row.get("current_subtask") or ""),
                            ", ".join(
                                str(item)
                                for item in (row.get("manipulated_objects") or [])
                            ),
                            str(row.get("target_location") or ""),
                        ]
                    )
                    for row in segments
                ],
            }
            write_saved_templates(templates)
        except Exception as exc:
            QMessageBox.warning(self, "模板保存失败", str(exc))
            return
        template_key = f"saved:{template_name}"
        existing = self.prefill_template_combo.findData(template_key)
        if existing < 0:
            self.prefill_template_combo.addItem(template_name, template_key)
            existing = self.prefill_template_combo.count() - 1
        self.prefill_template_combo.setCurrentIndex(existing)
        self.load_template(existing)
        self.prefill_status.setText(
            f"已保存模板“{template_name}”：{len(segments)} 段，"
            f"参考时长 {self.duration:.2f}s，包含全部时间比例。"
        )

    def delete_selected_template(self) -> None:
        index = self.prefill_template_combo.currentIndex()
        key = self.prefill_template_combo.itemData(index)
        name = self.prefill_template_combo.currentText()
        if not isinstance(key, str) or not key.startswith("saved:"):
            QMessageBox.information(
                self,
                "不能删除这个项目",
                "只能删除自己命名保存的模板。Episode 1 是动态参考项，"
                "不会写入模板库。",
            )
            return
        template_name = key.removeprefix("saved:")
        answer = QMessageBox.question(
            self,
            "删除模板？",
            f"确定永久删除模板“{name}”吗？",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        templates = load_saved_templates()
        if template_name not in templates:
            QMessageBox.warning(self, "删除失败", "模板库中已找不到该模板。")
            return
        del templates[template_name]
        try:
            write_saved_templates(templates)
        except Exception as exc:
            QMessageBox.critical(self, "删除失败", str(exc))
            return

        self.prefill_template_combo.blockSignals(True)
        self.prefill_template_combo.removeItem(index)
        if self.prefill_template_combo.count() == 0:
            self.prefill_template_combo.addItem(
                "暂无模板｜先加载并完成一个 episode，再保存为模板",
                "empty",
            )
        self.prefill_template_combo.setCurrentIndex(0)
        self.prefill_template_combo.blockSignals(False)
        self.load_template(0)
        self.prefill_status.setText(f"已删除模板“{name}”。")


def main() -> None:
    os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(
        Path(QLibraryInfo.location(QLibraryInfo.PluginsPath)) / "platforms"
    )
    app = QApplication(sys.argv)
    window = PrefillEditor()
    screen = app.primaryScreen().availableGeometry()
    width = max(640, min(1500, screen.width() - 40))
    height = max(480, min(980, screen.height() - 40))
    window.setGeometry(screen.left() + 20, screen.top() + 20, width, height)
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
