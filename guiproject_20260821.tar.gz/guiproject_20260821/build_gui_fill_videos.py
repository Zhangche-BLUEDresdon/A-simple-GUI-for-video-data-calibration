#!/usr/bin/env python3
"""Build GUI review videos for the subtask editor.

This is intentionally separate from the GUI so Load/select stays responsive.

Examples:
  python3 audit_tools/build_gui_fill_videos.py --dataset cabinet_open_fixed --limit 5
  python3 audit_tools/build_gui_fill_videos.py --dataset cabinet_open_fixed --episode episode_000000
  python3 audit_tools/build_gui_fill_videos.py --all
"""

from __future__ import annotations

import argparse
import importlib.util
import os
from pathlib import Path


ATOM_ROOT = Path(os.environ.get("ATOM_ROOT", Path(__file__).resolve().parents[1])).expanduser().resolve()
GUI_PATH = ATOM_ROOT / "audit_tools" / "subtask_editor_gui.py"


def import_gui():
    spec = importlib.util.spec_from_file_location("subtask_editor_gui", GUI_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {GUI_PATH}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=str(ATOM_ROOT / "classified_lerobot_v1"))
    ap.add_argument("--dataset", action="append", help="dataset name; repeatable")
    ap.add_argument("--episode", action="append", help="episode_000000; repeatable")
    ap.add_argument("--episode-from", type=int, default=None, help="inclusive episode index")
    ap.add_argument("--episode-to", type=int, default=None, help="inclusive episode index")
    ap.add_argument("--all", action="store_true", help="build all discovered episodes")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--overwrite", action="store_true")
    args = ap.parse_args()

    mod = import_gui()

    class Proxy:
        def __init__(self, root: Path):
            self.lerobot_root = root

        dataset_dir = mod.Editor.dataset_dir
        find_episode_camera_video = mod.Editor.find_episode_camera_video
        build_t_video = mod.Editor.build_t_video

    root = Path(args.root).expanduser().resolve()
    result_dirs = mod.discover_result_dataset_dirs(root)
    known = mod.lerobot_dataset_names(root)
    datasets = sorted(args.dataset or [ds for ds in result_dirs if not known or ds in known])
    proxy = Proxy(root)
    built = 0
    skipped = 0
    failed = 0
    for ds in datasets:
        rr = result_dirs.get(ds)
        if rr is None:
            print(f"MISS dataset sidecars: {ds}")
            failed += 1
            continue
        episodes = sorted(ep.name for ep in rr.glob("episode_*") if mod.result_files_in_episode_dir(ep))
        if args.episode:
            wanted = set(args.episode)
            episodes = [ep for ep in episodes if ep in wanted]
        if args.episode_from is not None or args.episode_to is not None:
            lo = 0 if args.episode_from is None else args.episode_from
            hi = 10**9 if args.episode_to is None else args.episode_to
            def ep_idx(ep: str) -> int:
                try:
                    return int(ep.replace("episode_", ""))
                except Exception:
                    return -1
            episodes = [ep for ep in episodes if lo <= ep_idx(ep) <= hi]
        ranged = args.episode_from is not None or args.episode_to is not None
        if not args.all and not args.episode and not args.limit and not ranged:
            episodes = episodes[:1]
        for ep in episodes:
            out = mod.GUI_VIDEO_ROOT / ds / f"{ep}_3hz_review.mp4"
            if out.exists() and not args.overwrite:
                skipped += 1
                print(f"SKIP {ds}/{ep} {out}")
            else:
                res = proxy.build_t_video(ds, ep, out)
                if res and res.exists():
                    built += 1
                    print(f"BUILT {ds}/{ep} {res}")
                else:
                    failed += 1
                    print(f"FAIL {ds}/{ep}")
            if args.limit and built + skipped + failed >= args.limit:
                print(f"done built={built} skipped={skipped} failed={failed}")
                return
    print(f"done built={built} skipped={skipped} failed={failed}")


if __name__ == "__main__":
    main()
